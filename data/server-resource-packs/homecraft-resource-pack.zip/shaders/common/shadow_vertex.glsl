#include "/lib/config.glsl"

/* Uniforms */

uniform mat4 shadowProjection;
uniform mat4 shadowProjectionInverse;
uniform mat4 shadowModelView;
uniform mat4 shadowModelViewInverse;

/* Ins / Outs */

varying vec2 texcoord;
varying float is_noshadow;

#ifdef COLORED_SHADOW
    varying float is_water;
#endif

attribute vec4 mc_Entity;

#if WAVING == 1
uniform vec3 cameraPosition;
uniform float frameTimeCounter;
uniform float rainStrength;
attribute vec2 mc_midTexCoord;
#include "/lib/vector_utils.glsl"
#endif

// MAIN FUNCTION ------------------

void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;

    vec4 position = shadowModelViewInverse * shadowProjectionInverse * gl_ModelViewProjectionMatrix * gl_Vertex;
    #if WAVING == 1
    bool hcLeaf = mc_Entity.x == ENTITY_LEAVES;
    bool hcGrass = mc_Entity.x == ENTITY_SMALLGRASS || mc_Entity.x == ENTITY_LOWERGRASS || mc_Entity.x == ENTITY_UPPERGRASS || mc_Entity.x == ENTITY_SMALLENTS;
    if (hcLeaf || hcGrass) {
        vec3 worldpos = position.xyz + cameraPosition;
        float weight = float(gl_MultiTexCoord0.t < mc_midTexCoord.t);
        if (mc_Entity.x == ENTITY_UPPERGRASS) weight += 1.0;
        else if (hcLeaf) weight = 0.3;
        else if (mc_Entity.x == ENTITY_SMALLENTS && (weight > 0.9 || fract(worldpos.y + 0.0675) > 0.01)) weight = 1.0;
        weight *= HC_WIND_STRENGTH;
        if (!hcLeaf) {
            float sky = (gl_TextureMatrix[1] * gl_MultiTexCoord1).y * 1.0323886639676114;
            weight *= sky * sky;
        }
        position.xyz += wave_move(worldpos.xzy) * weight * (0.018 + rainStrength * 0.025);
    }
    #endif
    gl_Position = shadowProjection * shadowModelView * position;

    float dist = length(gl_Position.xy);
    float distortFactor = dist * SHADOW_DIST + (1.0 - SHADOW_DIST);

    gl_Position.xy *= 1.0 / distortFactor;
    gl_Position.z = gl_Position.z * 0.2;

    is_noshadow = 0.0;
    if (mc_Entity.x == ENTITY_NO_SHADOW_FIRE || mc_Entity.x == ENTITY_F_EMMISIVE) {
        is_noshadow = 1.0;
    }

    #ifdef COLORED_SHADOW
        is_water = 0.0;

        if(mc_Entity.x == ENTITY_WATER) {
            is_water = 1.0;
        }
    #endif
}
