#include "/lib/config.glsl"

// MAIN FUNCTION ------------------

#if defined THE_END
    #include "/lib/color_utils_end.glsl"
#elif defined NETHER
    #include "/lib/color_utils_nether.glsl"
#endif

/* Uniforms */

uniform float viewWidth;
uniform float viewHeight;
uniform int frameCounter;
uniform sampler2D tex;
uniform int isEyeInWater;
uniform float nightVision;
uniform float rainStrength;
uniform float wetness;
uniform float dayNightMix;
uniform float pixelSizeX;
uniform float pixelSizeY;
uniform sampler2D gaux4;
uniform float frameTimeCounter;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;

#if defined DISTANT_HORIZONS
    uniform float dhNearPlane;
    uniform float far;
#endif

#if defined GBUFFER_ENTITIES
    uniform int entityId;
    uniform vec4 entityColor;
#endif

#ifdef NETHER
    uniform vec3 fogColor;
#endif

#if defined SHADOW_CASTING
    uniform sampler2DShadow shadowtex1;
    #if defined COLORED_SHADOW
        uniform sampler2DShadow shadowtex0;
        uniform sampler2D shadowcolor0;
    #endif
#endif

uniform float blindness;

#if MC_VERSION >= 11900
    uniform float darknessFactor;
    uniform float darknessLightFactor;
#endif

#ifdef MATERIAL_GLOSS
  // Don't remove
#endif

#if defined MATERIAL_GLOSS && !defined NETHER
    uniform int worldTime;
    uniform vec3 moonPosition;
    uniform vec3 sunPosition;
#endif

#if SHADOW_LOCK > 0 && defined SHADOW_CASTING
    // uniform vec3 cameraPosition;
    uniform mat4 shadowModelView;
    uniform mat4 shadowProjection;
    uniform vec3 shadowLightPosition;
#endif

uniform vec3 cameraPosition;

#if defined THE_END || (SHADOW_LOCK > 0 && defined SHADOW_CASTING && !defined NETHER)
    uniform mat4 gbufferModelView;
#endif

/* Ins / Outs */

varying vec2 texcoord;
varying vec4 tintColor;
varying float frogAdjust;
varying vec3 directLightColor;
varying vec3 candleColor;
varying float directLightStrength;
varying vec3 omniLight;

#if defined SHADOW_CASTING && SHADOW_LOCK > 0 && !defined NETHER
    varying vec3 vWorldPos;
    varying vec3 vNormal;
    varying vec3 vBias;
#endif

#if defined GBUFFER_TERRAIN || defined GBUFFER_HAND || defined GBUFFER_ENTITIES
    varying float isEmissiveEntity;
#endif

varying float isEndPortal;  // END PORTAL LIKE NEEDED

#ifdef FOLIAGE_V
    varying float isFoliage;
#endif

#if defined SHADOW_CASTING && !defined NETHER
    varying vec3 shadowPos;
    varying float shadowDiffuse;
#endif

#if defined MATERIAL_GLOSS && !defined NETHER
    varying vec3 flatNormal;
    varying vec3 viewPositionNormalized;
    varying vec2 lmcoordAlt;
    varying float glossFactor;
    varying float glossPower;
    varying float lumaFactor;
    varying float lumaPower;
#endif

/* Utility functions */

#if (defined SHADOW_CASTING && !defined NETHER) || defined DISTANT_HORIZONS
    // #include "/lib/dither.glsl"  // RELOCATED BY END PORTAL
#endif

// END PORTAL LIKE NEEDED
#include "/lib/basic_utils.glsl"
#include "/lib/dither.glsl"

#if defined SHADOW_CASTING && !defined NETHER
    #include "/lib/shadow_frag.glsl"
#endif

#include "/lib/luma.glsl"

#if defined MATERIAL_GLOSS && !defined NETHER
    #include "/lib/material_gloss_fragment.glsl"
#endif

#if defined SHADOW_CASTING && SHADOW_LOCK > 0 && !defined NETHER
    #include "/lib/shadow_vertex.glsl"
#endif

// END PORTAL LIKE NEEDED
#include "/lib/end_portal.glsl"

void main() {
    #if (defined SHADOW_CASTING && !defined NETHER) || defined DISTANT_HORIZONS
        #if AA_TYPE > 0
            float dither = shiftedDither13(gl_FragCoord.xy);
        #else
            float dither = dither17(gl_FragCoord.xy);
        #endif
    #endif
    // Avoid render in DH transition
    #if defined DISTANT_HORIZONS && !defined GBUFFER_BEACONBEAM
        float t = far - dhNearPlane;
        float sup = t * TRANSITION_DH_SUP;
        float inf = t * TRANSITION_DH_INF;
        float umbral = (gl_FogFragCoord - (dhNearPlane + inf)) / (far - sup - inf - dhNearPlane);
        if(umbral > dither) {
            discard;
            return;
        }
    #endif

    // Toma el color puro del bloque
    #if defined GBUFFER_ENTITIES && BLACK_ENTITY_FIX == 1
        vec4 blockColor = texture2D(tex, texcoord);
        if(blockColor.a < 0.1 && entityId != 10101) {   // Black entities bug workaround
            discard;
        }
        blockColor *= tintColor;
    #else
        vec4 blockColor = texture2D(tex, texcoord) * tintColor;
    #endif

    #if defined GBUFFER_ENTITIES
        vec4 originalEntityColor = blockColor;
    #endif

    #ifdef FOLIAGE_V
    if (isFoliage > 0.2 && blockColor.a < 0.1) discard;
    #endif
    float block_luma = luma(blockColor.rgb);

    float isEmissiveEntityLocal = 0.0;
    #if defined GBUFFER_ENTITIES
        if (isEmissiveEntity > 0.5 || entityId == 10202) {  // Custom lanterns
            isEmissiveEntityLocal = 1.0;
        }
    #endif

    vec3 finalCandleColor = candleColor;
    #if defined GBUFFER_TERRAIN || defined GBUFFER_HAND || defined GBUFFER_ENTITIES
        if(isEmissiveEntityLocal > 0.5) {
            finalCandleColor *= block_luma * 1.5;
        }
    #endif

    #ifdef GBUFFER_WEATHER
        #if HC_WEATHER_EFFECTS == 1
        blockColor.a *= mix(0.22, HC_FOREVER_QUALITY == 2 ? 0.48 : 0.32, rainStrength);
        blockColor.rgb *= mix(vec3(1.0), vec3(0.96, 0.99, 1.04), rainStrength);
        #else
        blockColor.a *= .5;
        #endif
    #endif

    #if defined GBUFFER_ENTITIES
        // Thunderbolt render
        if(entityId == 10101) {
            blockColor.a = 1.0;
        }
    #endif

    // NEW GLINT METHOD IN IRIS (MC >= 26.3)
    #ifdef IRIS_INLINE_GLINT
        if (mc_hasGlint()) {
            vec3 glint = mc_sampleGlint();
            blockColor.rgb += glint;
        }
    #endif

    // END PORTAL LIKE
    if(isEndPortal > 0.5) {
        blockColor.rgb = endPortal();
    }

    #if defined SHADOW_CASTING && !defined NETHER
        #if SHADOW_LOCK > 0
            vec3 offsetVector = vNormal * 0.002;
            vec3 preSnapPos = vWorldPos + offsetVector;
            float texelSize = SHADOW_LOCK;
            vec3 absPos = preSnapPos + cameraPosition;
            // Redondeo al bloque
            vec3 snappedAbsolute = floor(absPos * texelSize) / texelSize;
            snappedAbsolute += 0.5 / texelSize; // Centrar en el texel
            vec3 final_world_pos = (snappedAbsolute - cameraPosition) + vBias;
            vec3 shadow_real_pos = get_shadow_pos(final_world_pos);
        #else
            vec3 shadow_real_pos = shadowPos;
        #endif

        #if defined COLORED_SHADOW
            vec3 shadowValue = get_colored_shadow(shadow_real_pos, dither);
            shadowValue = mix(shadowValue, vec3(1.0), shadowDiffuse);
        #else
            float shadowValue = get_shadow(shadow_real_pos, dither);
            shadowValue = mix(shadowValue, 1.0, shadowDiffuse);
        #endif
    #else
        float shadowValue = abs((dayNightMix * 2.0) - 1.0);
    #endif

    #if defined GBUFFER_BEACONBEAM
        blockColor.rgb *= 1.5;
    #elif defined GBUFFER_ENTITY_GLOW
        blockColor.rgb =
            clamp(vec3(luma(blockColor.rgb)) * vec3(0.75, 0.75, 1.5), vec3(0.3), vec3(1.0));        
        vec3 realLight = omniLight +
                (shadowValue * directLightColor * directLightStrength) * (1.0 - (rainStrength * 0.75)) +
                finalCandleColor;
    #else
        #if defined MATERIAL_GLOSS && !defined NETHER
            float final_gloss_power = glossPower;
            block_luma *= lumaFactor;

            if(lumaPower < 0.0) {  // Metallic
                final_gloss_power -= (block_luma * 73.334);
            } else {
                block_luma = pow(block_luma, lumaPower);
            }

            float material_gloss_factor = materialGloss(reflect(viewPositionNormalized, flatNormal), lmcoordAlt, final_gloss_power, flatNormal) * glossFactor;

            float material = material_gloss_factor * block_luma;
            vec3 realLight = omniLight +
                (shadowValue * ((directLightColor * directLightStrength) + (directLightColor * material))) * (1.0 - (rainStrength * 0.75)) +
                finalCandleColor;
        #else
            vec3 realLight = omniLight +
                (shadowValue * directLightColor * directLightStrength) * (1.0 - (rainStrength * 0.75)) +
                finalCandleColor;
        #endif

        blockColor.rgb *= mix(realLight, vec3(1.0), nightVision * 0.125);
        blockColor.rgb *= mix(vec3(1.0, 1.0, 1.0), vec3(NV_COLOR_R, NV_COLOR_G, NV_COLOR_B), nightVision);
    #endif

    #if HC_WET_SURFACES == 1 && defined GBUFFER_TERRAIN && defined MATERIAL_GLOSS && !defined NETHER && !defined THE_END && !defined UNKNOWN_DIM
        float hcTop = smoothstep(0.65, 0.95, (mat3(gbufferModelViewInverse) * flatNormal).y);
        float hcWet = clamp(wetness, 0.0, 1.0) * hcTop * smoothstep(0.70, 0.98, lmcoordAlt.y);
        #ifdef FOLIAGE_V
        hcWet *= 1.0 - step(0.2, isFoliage);
        #endif
        hcWet *= 1.0 - clamp(blindness, 0.0, 1.0);
        #if MC_VERSION >= 11900
        hcWet *= 1.0 - clamp(darknessFactor, 0.0, 1.0);
        #endif
        if (isEyeInWater == 0) {
            blockColor.rgb *= 1.0 - hcWet * (HC_FOREVER_QUALITY == 2 ? 0.10 : 0.04);
            float hcFresnel = pow(1.0 - abs(dot(flatNormal, viewPositionNormalized)), 5.0);
            blockColor.rgb += directLightColor * hcWet * (0.025 + hcFresnel * (HC_FOREVER_QUALITY == 2 ? 0.09 : 0.035));
            #if HC_FOREVER_QUALITY == 2
            vec3 hcLight = normalize(dayNightMix < 0.5 ? moonPosition : sunPosition);
            float hcSpec = pow(max(dot(reflect(viewPositionNormalized, flatNormal), hcLight), 0.0), 64.0);
            blockColor.rgb += directLightColor * hcSpec * hcWet * shadowValue * 0.16 * abs(dayNightMix * 2.0 - 1.0);
            #endif
        }
    #endif

    #if defined GBUFFER_ENTITIES
        if(entityId == 10101) {  // Thunderbolt render
            blockColor = vec4(1.0, 1.0, 1.0, 0.5);
        } else if (entityId == 10201) {  // Flame entity
            blockColor = originalEntityColor;
            blockColor.rgb = blockColor.rgb * blockColor.rgb;
        } else {
            float entity_poderation = luma(realLight);  // Red damage bright ponderation
            blockColor.rgb = mix(blockColor.rgb, entityColor.rgb, entityColor.a * entity_poderation * 3.0);
        }
    #endif

    #if MC_VERSION < 11300 && defined GBUFFER_TEXTURED
        blockColor.rgb *= 1.5;
    #endif

    #include "/src/finalcolor.glsl"
    #include "/src/writebuffers.glsl"
}
