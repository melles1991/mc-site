/* MakeUp - water.glsl
Water reflection and refraction related functions.
*/

float linearizeDepth(float depth) {
    return gbufferProjection[3][2] / (gbufferProjection[2][2] + 2.0 * depth - 1.0);
}

vec3 fastRaymarch(vec3 direction, vec3 hitPoint, inout float infinite, float dither) {
    infinite = 1.0;
    vec3 ray = normalize(direction);
    float previous = 0.18;
    for (int i = 0; i < RAYMARCH_STEPS; i++) {
        float u = (float(i) + 1.0) / float(RAYMARCH_STEPS);
        float distance = 0.18 + u * u * 64.0;
        vec3 samplePos = hitPoint + ray * distance;
        vec3 uv = camera_to_screen(samplePos);
        if (uv.x <= 0.001 || uv.x >= 0.999 || uv.y <= 0.001 || uv.y >= 0.999 || uv.z <= 0.0 || uv.z >= 1.0) break;
        float depth = texture2D(depthtex1, uv.xy).r;
        float delta = -samplePos.z - linearizeDepth(depth);
        float thickness = 0.30 + distance * 0.025;
        if (depth > 0.56 && depth < 0.9999 && delta > 0.0 && delta < thickness) {
            float low = previous, high = distance;
            for (int j = 0; j < 2; j++) {
                float mid = (low + high) * 0.5;
                vec3 v = hitPoint + ray * mid;
                vec3 projected = camera_to_screen(v);
                float scene = linearizeDepth(texture2D(depthtex1, clamp(projected.xy, vec2(0.001), vec2(0.999))).r);
                if (-v.z > scene) high = mid; else low = mid;
            }
            vec3 result = camera_to_screen(hitPoint + ray * high);
            infinite = 0.0;
            return result;
        }
        previous = distance;
    }
    return vec3(0.5, 0.5, 1.0); // caller uses infinite to choose the sky fallback
}

#include "/lib/hc_forever_water.glsl"

#if SUN_REFLECTION == 1
    #if !defined NETHER && !defined THE_END
        float sun_reflection(vec3 fragpos) {
            vec3 astroLightPos = hc_active_light(sunPosition, moonPosition, dayNightMix);
            float astroAlignment =
                max(dot(normalize(fragpos), normalize(astroLightPos)), 0.0);

            return smoothstep(0.995, 1.0, astroAlignment) *
                clamp(lmcoord.y, 0.0, 1.0) *
                (1.0 - rainStrength) * 2.0 * abs(dayNightMix * 2.0 - 1.0);
        }
    #endif
#endif

vec3 normal_waves(vec3 pos) {
    float speed = mod(frameTimeCounter, 40.0) * .025;
    vec2 wave_1 =
        texture2D(noisetex, ((pos.xy - pos.z * 0.2) * 0.05) + vec2(speed, speed)).rg;
    wave_1 = wave_1 - .5;
    vec2 wave_2 =
        texture2D(noisetex, ((pos.xy - pos.z * 0.2) * 0.03125) - speed).rg;
    wave_2 = wave_2 - .5;
    #if HC_LIGHT_BUDGET == 0
    vec2 wave_3 =
        texture2D(noisetex, ((pos.xy - pos.z * 0.2) * 0.125) + vec2(speed, -speed)).rg;
    wave_3 = wave_3 - .5;
    wave_3 *= 0.66;

    vec2 partialWave = wave_1 + wave_2 + wave_3;
    #else
    vec2 partialWave = wave_1 + wave_2;
    #endif
    partialWave += hc_rain_ripple(pos.xy) * rainStrength * visibleSky;
    vec3 finalWave = vec3(partialWave, WATER_TURBULENCE - (rainStrength * 0.6 * WATER_TURBULENCE * visibleSky));

    return normalize(finalWave);
}

vec3 refraction(vec3 fragpos, vec3 color, vec3 refraction) {
    vec2 pos = gl_FragCoord.xy * vec2(pixelSizeX, pixelSizeY);

    #if REFRACTION == 1
        pos = clamp(pos + refraction.xy * (0.075 / (1.0 + length(fragpos) * 0.4)), vec2(0.001), vec2(0.999));
    #endif

    float water_absortion;
    if (isEyeInWater == 0) {
        float water_distance = linearizeDepth(gl_FragCoord.z);
        float earth_depth = texture2D(depthtex1, pos.xy).r;
        float earth_distance = linearizeDepth(earth_depth);

        #if defined DISTANT_HORIZONS
            float earth_distance_dh = texture2D(dhDepthTex1, pos.xy).r;
            earth_distance_dh =
                2.0 * dhNearPlane * dhFarPlane / (dhFarPlane + dhNearPlane - (2.0 * earth_distance_dh - 1.0) * (dhFarPlane - dhNearPlane));
            earth_distance = min(earth_distance, earth_distance_dh);
        #endif

        if (earth_distance < water_distance) {
            pos = gl_FragCoord.xy * vec2(pixelSizeX, pixelSizeY);
            earth_distance = linearizeDepth(texture2D(depthtex1, pos).r);
        }
        water_absortion = max(earth_distance - water_distance, 0.0);
        water_absortion *= water_absortion;
        water_absortion = (1.0 / -((water_absortion * WATER_ABSORPTION) + 1.125)) + 1.0;
    } else {
        water_absortion = 0.0;
    }

    return mix(texture2D(gaux1, pos.xy).rgb, color, water_absortion);
}

vec3 get_normals(vec3 bump, vec3 fragpos) {
    float NdotE = abs(dot(waterNormal, normalize(fragpos)));

    bump *= vec3(NdotE) + vec3(0.0, 0.0, 1.0 - NdotE);

    mat3 tbn_matrix = mat3(
        tangent.x, binormal.x, waterNormal.x,
        tangent.y, binormal.y, waterNormal.y,
        tangent.z, binormal.z, waterNormal.z
    );

    return normalize(bump * tbn_matrix);
}

vec4 reflection_calc(vec3 fragpos, vec3 normal, vec3 reflected, inout float infinite, float dither) {
    #if SSR_TYPE == 0  // Flipped image
        #if defined DISTANT_HORIZONS || defined VOXY
            vec3 pos = camera_to_screen(fragpos + reflected * 768.0);
        #else
            vec3 pos = camera_to_screen(fragpos + reflected * 76.0);
        #endif
    #else  // Raymarch
        vec3 pos = fastRaymarch(reflected, fragpos, infinite, dither);
    #endif

    float border =
        clamp((1.0 - (max(0.0, abs(pos.y - 0.5)) * 2.0)) * 50.0, 0.0, 1.0);

    border = clamp(border - pow(pos.y, 10.0), 0.0, 1.0);

    #if SSR_TYPE > 0
    border *= 1.0 - infinite;
    border *= smoothstep(0.0, 0.05, min(min(pos.x, 1.0-pos.x), min(pos.y, 1.0-pos.y)));
    #endif
    pos.x = abs(pos.x);
    if (pos.x > 1.0) {
        pos.x = 1.0 - (pos.x - 1.0);
    }

    return vec4(texture2D(gaux1, pos.xy).rgb, border);
}

vec3 water_shader(
    vec3 fragpos,
    vec3 normal,
    vec3 color,
    vec3 sky_reflect,
    vec3 reflected,
    float fresnel,
    float visibleSky,
    float dither,
    vec3 lightColor
) {
    vec4 reflection = vec4(0.0);
    float infinite = 1.0;

    #if REFLECTION == 1
        reflection =
            reflection_calc(fragpos, normal, reflected, infinite, dither);
    #endif

    reflection.rgb = mix(
        sky_reflect * visibleSky,
        reflection.rgb,
        reflection.a
    );

    #ifdef VANILLA_WATER
        fresnel *= 0.8;
    #endif

    #if SUN_REFLECTION == 1
        #ifndef NETHER
            #ifndef THE_END
                return mix(color, reflection.rgb, fresnel * REFLEX_INDEX) +
                    vec3(sun_reflection(reflect(normalize(fragpos), normal))) * lightColor * infinite * visibleSky;
            #else
                return mix(color, reflection.rgb, fresnel * REFLEX_INDEX);
            #endif
        #else
            return mix(color, reflection.rgb, fresnel * REFLEX_INDEX);
        #endif
    #else
        return mix(color, reflection.rgb, fresnel * REFLEX_INDEX);
    #endif
}

//  GLASS

vec4 cristal_reflection_calc(vec3 fragpos, vec3 normal, inout float infinite, float dither) {
    #if SSR_TYPE == 0
        #if defined DISTANT_HORIZONS || defined VOXY
            vec3 reflectedVector = reflect(normalize(fragpos), normal) * 768.0;
        #else
            vec3 reflectedVector = reflect(normalize(fragpos), normal) * 76.0;
        #endif
        vec3 pos = camera_to_screen(fragpos + reflectedVector);
    #else
        vec3 reflectedVector = reflect(normalize(fragpos), normal);
        vec3 pos = fastRaymarch(reflectedVector, fragpos, infinite, dither);

        if (pos.x > 99.0) { // Fallback
            #if defined DISTANT_HORIZONS
                pos = camera_to_screen(fragpos + reflectedVector * 768.0);
            #else
                pos = camera_to_screen(fragpos + reflectedVector * 76.0);
            #endif
        }
    #endif

    float border_x = max(-fourthPow(abs(2.0 * pos.x - 1.0)) + 1.0, 0.0);
    float border_y = max(-fourthPow(abs(2.0 * pos.y - 1.0)) + 1.0, 0.0);
    float border = min(border_x, border_y);

    #if SSR_TYPE > 0
    border *= 1.0 - infinite;
    #endif
    return vec4(texture2D(gaux1, clamp(pos.xy, vec2(0.001), vec2(0.999)), 0.0).rgb, border);
}

vec4 cristal_shader(
    vec3 fragpos,
    vec3 normal,
    vec4 color,
    vec3 skyReflectionColor,
    float fresnel,
    float visibleSky,
    float dither,
    vec3 lightColor
) {
    vec4 reflection = vec4(0.0);
    float infinite = 0.0;

    #if REFLECTION == 1
        reflection = cristal_reflection_calc(fragpos, normal, infinite, dither);
    #endif

    skyReflectionColor = mix(color.rgb, skyReflectionColor, visibleSky * visibleSky);

    reflection.rgb = mix(
        skyReflectionColor,
        reflection.rgb,
        reflection.a
    );

    color.rgb = mix(color.rgb, skyReflectionColor, fresnel);
    color.rgb = mix(color.rgb, reflection.rgb, fresnel);

    color.a = mix(color.a, 1.0, fresnel * .9);

    #if SUN_REFLECTION == 1
        #ifndef NETHER
        #ifndef THE_END
            return color + vec4(
                mix(
                    vec3(sun_reflection(reflect(normalize(fragpos), normal)) * lightColor * infinite * visibleSky),
                    vec3(0.0),
                    reflection.a
                ),
                0.0
            );
        #else
            return color;
        #endif
        #else
            return color;
        #endif
    #else
        return color;
    #endif
}
