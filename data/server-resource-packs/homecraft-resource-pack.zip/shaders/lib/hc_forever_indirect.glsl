/* HomeCraft R18: four depth-gated screen-space color samples.
   Approximate local color bleed; unseen/off-screen surfaces cannot contribute. */
vec3 hc_indirect(vec3 color, float depth) {
    #if HC_INDIRECT_LIGHT == 1 && HC_FOREVER_QUALITY == 2
    if (depth < 0.56 || depth > 0.9999 || blindness > 0.01) return color;
    float dist = ld(depth) * far;
    float radius = clamp(14.0 / max(dist, 1.0), 2.0, 14.0);
    vec2 pixel = vec2(pixelSizeX, pixelSizeY) * radius;
    vec3 bleed = vec3(0.0);
    for (int i = 0; i < 4; i++) {
        vec2 dir = i == 0 ? vec2(1.0, 0.0) : (i == 1 ? vec2(-1.0, 0.0) : (i == 2 ? vec2(0.0, 1.0) : vec2(0.0, -1.0)));
        vec2 uv = clamp(texcoord + dir * pixel, vec2(0.001), vec2(0.999));
        float sampleDepth = texture2D(depthtex0, uv).r;
        float delta = abs(ld(sampleDepth) * far - dist);
        float weight = (1.0 - smoothstep(0.25, 2.0, delta)) * step(0.56, sampleDepth) * (1.0 - step(0.9999, sampleDepth));
        bleed += clamp(texture2D(colortex1, uv).rgb, vec3(0.0), vec3(1.0)) * weight;
    }
    float suppress = 1.0;
    #if MC_VERSION >= 11900
    suppress = 1.0 - clamp(darknessFactor, 0.0, 1.0);
    #endif
    color += bleed * 0.0075 * suppress; // absolute maximum +0.03 per channel
    #endif
    return color;
}
