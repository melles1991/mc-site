/* HomeCraft R20. Original analytic sky, LGPL-3.0.
   Shared by sky background and water fallback reflection. No texture lookups.
   Inputs are world-space unit directions and the pack's RGB sky palette. */
vec3 hc_natural_sky(vec3 ray, vec3 sunRay, vec3 zenith, vec3 horizon, float rain, float moment) {
    float height = clamp(ray.y, 0.0, 1.0);
    float gradient = smoothstep(0.0, 1.0, sqrt(height));
    vec3 sky = mix(horizon, zenith, gradient);
    float sunHeight = sunRay.y;
    float twilight = (1.0 - smoothstep(0.06, 0.32, abs(sunHeight))) * smoothstep(-0.22, -0.04, sunHeight);
    float morning = 0.5 + 0.5 * cos(moment * 6.28318530718);
    float towardSun = clamp(dot(ray, sunRay), 0.0, 1.0);
    float forward = towardSun * towardSun * towardSun;
    forward *= forward;
    float lowAir = exp2(-height * 8.0);
    float clear = 1.0 - clamp(rain, 0.0, 1.0) * 0.92;
    // Dawn is cooler peach; dusk amber. Warmth stays near the light source.
    vec3 warm = mix(vec3(0.85, 0.40, 0.20), vec3(0.82, 0.55, 0.42), morning);
    sky = mix(sky, warm, twilight * lowAir * (0.08 + 0.68 * forward) * clear);
    #if HC_FOREVER_QUALITY == 2
        // Subtle anti-solar rose band and restrained aureole, not a second sun disc.
        float belt = exp2(-abs(height - 0.09) * 20.0) * (1.0 - forward);
        sky = mix(sky, vec3(0.38, 0.30, 0.43), belt * twilight * clear * 0.16);
        float halo = forward * forward * forward;
        sky += vec3(0.065, 0.052, 0.035) * halo * clear * smoothstep(-0.08, 0.12, sunHeight);
    #endif
    return max(sky, vec3(0.0));
}
