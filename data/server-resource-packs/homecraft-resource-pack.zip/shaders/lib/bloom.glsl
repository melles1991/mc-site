/* MakeUp - bloom.glsl
Bloom functions.

Javier Garduño - GNU Lesser General Public License v3.0
*/

vec3 mipmap_bloom(sampler2D image, vec2 coords, float dither) {
    vec3 blurSample = vec3(0.0);
    vec2 blurRadiusVec = vec2(0.1 * aspectRatioInverse, 0.1);

    #if HC_LIGHT_BUDGET == 1
    int samplesQuantity = 2;
    #else
    int samplesQuantity = int(BLOOM_SAMPLES);
    #endif

    #if HC_LIGHT_BUDGET == 1
    vec2 blurRadiusFactor = blurRadiusVec * 0.5;
    #else
    vec2 blurRadiusFactor = blurRadiusVec * (1.0 / BLOOM_SAMPLES);
    #endif
    float n;
    vec2 offset;
    vec2 offset2;
    float ditherShifted;

    for(int i = 0; i < samplesQuantity; i++) {
        ditherShifted = i + dither;
        n = fract(ditherShifted * 1.6180339887) * 6.283185307179586;
        offset = vec2(cos(n), sin(n)) * ditherShifted * blurRadiusFactor;
        offset2 = vec2(-offset.y * 1.25, offset.x * 1.25);

        blurSample += texture2DLod(image, coords + offset, softLod).rgb;
        blurSample += texture2DLod(image, coords - offset, softLod).rgb;
        #if HC_LIGHT_BUDGET == 0
        blurSample += texture2DLod(image, coords + offset2, softLod).rgb;
        blurSample += texture2DLod(image, coords - offset2, softLod).rgb;
        #endif
    }

    #if HC_LIGHT_BUDGET == 1
    blurSample *= 0.25;
    #else
    blurSample /= (BLOOM_SAMPLES * 4.0);
    #endif

    return blurSample;
}
