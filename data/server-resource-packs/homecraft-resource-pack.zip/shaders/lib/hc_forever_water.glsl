/* HomeCraft R18: authored periodic ripple/foam math; no external textures. */
vec2 hc_rain_ripple(vec2 p) {
    #if HC_RAIN_RIPPLES == 1
    #if HC_FOREVER_QUALITY == 2
    vec2 cell = floor(p * 1.5);
    vec2 local = fract(p * 1.5);
    vec2 result = vec2(0.0);
    // Adjacent cells prevent a hard discontinuity at tile borders.
    for (int y = -1; y <= 1; y++) {
        for (int x = -1; x <= 1; x++) {
            vec2 offset = vec2(float(x), float(y));
            vec2 c = cell + offset;
            float hash = fract(sin(dot(c, vec2(127.1, 311.7))) * 43758.5453);
            vec2 delta = local - offset - vec2(0.2 + 0.6 * hash, 0.2 + 0.6 * fract(hash * 17.0));
            float age = fract(mod(frameTimeCounter, 4.0) * 0.5 + hash);
            float envelope = sin(age * 3.1415926536);
            envelope *= envelope;
            float r = length(delta);
            float band = r - age * 0.6;
            float ring = exp(-band * band * 110.0) * envelope;
            result += delta / max(r, 0.001) * ring * (1.0 - smoothstep(0.60, 0.72, r));
        }
    }
    return result * 0.10;
    #else
    float phase = mod(frameTimeCounter, 8.0) * 0.7853981634;
    return vec2(sin(p.x * 3.0 + phase * 2.0), cos(p.y * 3.0 - phase * 2.0)) * 0.025;
    #endif
    #else
    return vec2(0.0);
    #endif
}

vec3 hc_shore_foam(vec3 color, vec3 surfacePos, vec3 worldPos, float topFace, vec3 light, float sky) {
    #if HC_SHORE_FOAM == 1
    if (isEyeInWater == 0 && topFace > 0.8) {
        vec2 uv = gl_FragCoord.xy * vec2(pixelSizeX, pixelSizeY);
        float depth = texture2D(depthtex1, uv).r;
        float thickness = linearizeDepth(depth) - linearizeDepth(gl_FragCoord.z);
        if (depth > 0.56 && depth < 0.9999 && thickness >= 0.0) {
            float edge = (1.0 - smoothstep(0.04, 0.65, thickness)) * clamp(sky, 0.0, 1.0);
            #if HC_FOREVER_QUALITY == 2
            float drift = mod(frameTimeCounter, 40.0) * 0.025;
            float n = texture2D(noisetex, worldPos.xz * 0.28 + vec2(drift, -drift)).r;
            edge *= smoothstep(0.24, 0.70, n) * 0.32;
            #else
            edge *= 0.10;
            #endif
            color = mix(color, vec3(0.62, 0.76, 0.74) * light, edge);
        }
    }
    #endif
    return color;
}
