/* HomeCraft R20: eased cyclic lighting; sunrise/dusk remain continuous.
   Keep the upstream signatures for DH/Voxy compatibility. */
uniform float sunAngle;
vec3 hc_active_light(vec3 sun, vec3 moon, float blend) {
    // Opposite sun/moon vectors cancel at blend0.5. Select a valid source;
    // callers fade its intensity through twilight instead of normalizing zero.
    return mix(moon, sun, step(0.5, blend));
}

vec3 hc_twilight_tint(vec3 color, float moment) {
    #if !defined NETHER && !defined THE_END && !defined UNKNOWN_DIM
        float morning = 0.5 + 0.5 * cos(moment * 6.28318530718);
        return color * mix(vec3(1.0, 0.99, 0.98), vec3(0.98, 1.02, 1.08), morning);
    #else
        return color;
    #endif
}
vec3 dayBlendVoxy(vec3 sunset, vec3 day, vec3 night, float dayMixerV, float nightMixerV, float dayMomentV) {
    vec3 twilight = hc_twilight_tint(sunset, dayMomentV);
    vec3 dayColor = mix(twilight, day, smoothstep(0.0, 1.0, dayMixerV));
    vec3 nightColor = mix(twilight, night, smoothstep(0.0, 1.0, nightMixerV));
    return mix(dayColor, nightColor, step(0.5, dayMomentV));
}
float dayBlendFloatVoxy(float sunset, float day, float night, float dayMixerV, float nightMixerV, float dayMomentV) {
    float dayValue = mix(sunset, day, smoothstep(0.0, 1.0, dayMixerV));
    float nightValue = mix(sunset, night, smoothstep(0.0, 1.0, nightMixerV));
    return mix(dayValue, nightValue, step(0.5, dayMomentV));
}
vec3 dayBlend(vec3 sunset, vec3 day, vec3 night) {
    return dayBlendVoxy(sunset, day, night, dayMixer, nightMixer, dayMoment);
}
float dayBlendFloat(float sunset, float day, float night) {
    return dayBlendFloatVoxy(sunset, day, night, dayMixer, nightMixer, dayMoment);
}
