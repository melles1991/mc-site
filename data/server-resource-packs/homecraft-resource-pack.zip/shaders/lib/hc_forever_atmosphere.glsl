/* HomeCraft R18, 2026-10-25. Original Minecraft adaptation, LGPL-3.0.
   Fog, indirect color bleed and caustics approximate the Forever visual style.
   They are not Blizzard's renderer or a physically traced GI solution. */

vec3 hc_world_ray(vec2 uv, float depth) {
    vec4 v = gbufferProjectionInverse * vec4(uv * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
    return mat3(gbufferModelViewInverse) * (v.xyz / max(abs(v.w), 0.00001));
}

vec3 hc_forever_atmosphere(vec3 color, float depth) {
    #if !defined NETHER && !defined THE_END && !defined UNKNOWN_DIM
    // Hand/foreground and status effects must remain readable.
    if (depth < 0.56 || isEyeInWater > 1) return color;
    vec3 ray = hc_world_ray(texcoord, depth);
    float distanceToSurface = length(ray);
    vec3 direction = ray / max(distanceToSurface, 0.0001);
    float outdoors = clamp(float(eyeBrightnessSmooth.y) / 240.0, 0.0, 1.0);
    float visibility = 1.0 - clamp(blindness, 0.0, 1.0);
    #if MC_VERSION >= 11900
    visibility *= 1.0 - clamp(darknessFactor, 0.0, 1.0);
    #endif
    float time = mod(frameTimeCounter, 40.0) * 0.025;

    #if HC_FOREVER_FOG == 1
    if (isEyeInWater == 0 && outdoors > 0.01) {
        float travel = min(distanceToSurface, 128.0);
        float opticalDepth = 0.0;
        #if HC_FOREVER_QUALITY == 2
        // Six bounded world-space density samples; no new framebuffer/pass.
        for (int i = 0; i < 6; i++) {
            vec3 p = cameraPosition + direction * travel * ((float(i) + 0.5) / 6.0);
            float n = texture2D(noisetex, p.xz * 0.004 + vec2(time, -time)).r;
            float n2 = texture2D(noisetex, p.xz * 0.011 + vec2(-time, 0.0)).g;
            float heightDensity = exp2(-max(p.y - 64.0, 0.0) * 0.035);
            opticalDepth += (0.0015 + 0.006 * heightDensity) * mix(0.40, 1.25, n * n2);
        }
        opticalDepth *= travel / 6.0;
        #else
        // Analytic height haze: no texture fetch or marching on weak PCs.
        float midHeight = cameraPosition.y + direction.y * travel * 0.5;
        opticalDepth = travel * (0.001 + 0.0025 * exp2(-max(midHeight - 64.0, 0.0) * 0.035));
        #endif
        float mist = (1.0 - exp2(-opticalDepth * (1.0 + rainStrength * 2.0))) * HC_FOG_STRENGTH;
        mist = clamp(mist * outdoors * visibility, 0.0, 0.55);
        vec3 fog = mix(vec3(0.43, 0.58, 0.67), vec3(0.29, 0.40, 0.52), rainStrength);
        fog *= max(directLightColor, vec3(0.025)) * 0.75;
        color = mix(color, fog, mist);
    }
    #endif

    #if HC_CAUSTICS == 1
    if (isEyeInWater == 1 && depth < 0.9999) {
        vec3 p = cameraPosition + ray;
        #if HC_FOREVER_QUALITY == 2
        vec2 a = texture2D(noisetex, p.xz * 0.11 + vec2(time, -time)).rg;
        vec2 b = texture2D(noisetex, p.xz * 0.16 + vec2(-time, time)).rg;
        float pattern = 1.0 - smoothstep(0.015, 0.12, abs((a.r + b.r) - (a.g + b.g)));
        float intensity = 0.11;
        #else
        float phase = mod(frameTimeCounter, 8.0) * 0.7853981634;
        float pattern = pow(max(0.0, sin(p.x * 1.4 + phase) * sin(p.z * 1.4 - phase)), 4.0);
        float intensity = 0.035;
        #endif
        color += vec3(0.52, 0.86, 1.0) * pattern * intensity * outdoors * visibility *
            exp2(-distanceToSurface * 0.055) * (1.0 - rainStrength * 0.7) * max(directLightColor, vec3(0.015));
    }
    #endif
    #endif
    return color;
}
