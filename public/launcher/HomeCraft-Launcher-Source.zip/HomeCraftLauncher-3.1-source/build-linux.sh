#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
mkdir -p build/classes
javac --release 17 -encoding UTF-8 -d build/classes src/ua/homecraft/launcher/*.java
printf 'Implementation-Version: 3.1.0\n' > build/manifest.mf
jar --create --file HomeCraftLauncher.jar --main-class ua.homecraft.launcher.HomeCraftLauncher --manifest build/manifest.mf -C build/classes . -C resources .
printf 'Готово: %s\n' 'HomeCraftLauncher.jar'
