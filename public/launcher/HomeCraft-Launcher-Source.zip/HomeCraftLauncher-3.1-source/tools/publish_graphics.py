"""Publish a HomeCraft graphics ZIP to an existing SITE/public folder.
Local file writes only. Does not deploy a server or change server.properties.
Usage: python tools/publish_graphics.py PACK.zip --public-dir ../SITE/public --site https://homecraft-mc.pp.ua
"""
from pathlib import Path
from zipfile import ZipFile
import argparse,hashlib,json,re,shutil,tempfile,os,urllib.parse
p=argparse.ArgumentParser();p.add_argument('pack',type=Path);p.add_argument('--public-dir',type=Path,required=True);p.add_argument('--site',default='https://homecraft-mc.pp.ua');a=p.parse_args()
name=a.pack.name;match=re.fullmatch(r'HomeCraft-Warcraft32-26\.3-(R[0-9]+)(?:-[A-Za-z0-9_-]+)?\.zip',name)
if not match:raise SystemExit('Expected a versioned HomeCraft Warcraft32 26.3 ZIP filename')
site=urllib.parse.urlsplit(a.site)
if site.scheme not in ('http','https') or not site.hostname or site.username or site.password or site.query or site.fragment or site.path not in ('','/'):raise SystemExit('Use a site origin URL only')
if not a.pack.is_file() or not 1<=a.pack.stat().st_size<=64*1024*1024:raise SystemExit('Invalid pack file/size')
with ZipFile(a.pack) as z:
    if z.testzip() is not None or not {'pack.mcmeta','shaders/shaders.properties'}.issubset(z.namelist()):raise SystemExit('Invalid combined resource/shader pack')
data=a.pack.read_bytes()
manifest={'schemaVersion':1,'product':'homecraft-graphics','minecraft':'26.3','release':match[1],'packId':'a728c545-31e3-48fa-a16d-5f19c19fc2ef','filename':name,'size':len(data),'sha256':hashlib.sha256(data).hexdigest(),'sha1':hashlib.sha1(data).hexdigest(),'url':'/resource-packs/'+name}
target=a.public_dir/'resource-packs'/name;target.parent.mkdir(parents=True,exist_ok=True)
if target.exists() and hashlib.sha256(target.read_bytes()).hexdigest()!=manifest['sha256']:raise SystemExit('A different file already uses this release name; publish under a new release')
meta=a.public_dir/'launcher/graphics-manifest.json';meta.parent.mkdir(parents=True,exist_ok=True)
if meta.exists():
    old=json.loads(meta.read_text())
    if re.fullmatch(r'R[0-9]+',str(old.get('release',''))) and int(old['release'][1:])>int(match[1][1:]):raise SystemExit('Refusing to replace a newer manifest with an older release')
def atomic(path,content):
    with tempfile.NamedTemporaryFile(dir=path.parent,delete=False) as f:f.write(content);temporary=Path(f.name)
    try:os.replace(temporary,path)
    finally:temporary.unlink(missing_ok=True)
if not target.exists():atomic(target,data)
atomic(meta,(json.dumps(manifest,indent=2)+'\n').encode())
print('Published local files:',target,meta,sep='\n')
print('\nserver.properties:')
print('resource-pack='+a.site.rstrip('/')+manifest['url'])
print('resource-pack-sha1='+manifest['sha1'])
print('resource-pack-id='+manifest['packId'])
print('require-resource-pack=true')
