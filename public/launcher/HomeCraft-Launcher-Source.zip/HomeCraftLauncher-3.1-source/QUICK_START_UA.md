# Швидкий старт 3.1

Збери: `sh build-linux.sh` або `build-windows.bat` (JDK 17+).

Запусти: `sh start-linux.sh`, `start-windows.bat` або `java -jar HomeCraftLauncher.jar`.

Налаштуй адресу сайту, інстанс Minecraft та зовнішній Minecraft/Prism Launcher. «Встановити / оновити» завантажить усі відсутні моди. «Грати» також виконує встановлення/оновлення перед запуском.

Для Minecraft 26.3 встанови Java 25 у налаштуваннях зовнішнього лаунчера.
