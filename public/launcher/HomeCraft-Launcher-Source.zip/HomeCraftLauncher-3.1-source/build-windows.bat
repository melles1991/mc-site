@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
if not exist build\classes mkdir build\classes
javac --release 17 -encoding UTF-8 -d build\classes src\ua\homecraft\launcher\Json.java src\ua\homecraft\launcher\HomeCraftUpdater.java src\ua\homecraft\launcher\GraphicsInstaller.java src\ua\homecraft\launcher\LauncherUI.java src\ua\homecraft\launcher\HomeCraftLauncher.java
if errorlevel 1 (echo Java compilation failed & exit /b 1)
echo Implementation-Version: 3.1.0> build\manifest.mf
jar --create --file HomeCraftLauncher.jar --main-class ua.homecraft.launcher.HomeCraftLauncher --manifest build\manifest.mf -C build\classes . -C resources .
if errorlevel 1 (echo JAR packaging failed & exit /b 1)
echo Ready: HomeCraftLauncher.jar
