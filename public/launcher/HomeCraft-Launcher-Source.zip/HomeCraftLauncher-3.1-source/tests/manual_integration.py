"""Manual tests, never called by a build. Requires Python 3 + Java 17+.
Uses disposable Minecraft folders and a local HTTP fixture. Optional real CDN
downloads verify Iris/Sodium distribution without launching either mod/game.
"""
from pathlib import Path
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from tempfile import TemporaryDirectory
from zipfile import ZipFile,ZipInfo,ZIP_DEFLATED
import argparse,hashlib,io,json,subprocess,threading,urllib.parse,urllib.request,fcntl

parser=argparse.ArgumentParser();parser.add_argument('--jar',type=Path,default=Path(__file__).resolve().parents[1]/'HomeCraftLauncher.jar');parser.add_argument('--online-renderers',action='store_true');args=parser.parse_args()
proxy=urllib.parse.urlsplit(urllib.request.getproxies().get('https',''))
java_options=(['-Dhttps.proxyHost='+proxy.hostname,'-Dhttps.proxyPort='+str(proxy.port or 80)] if proxy.hostname else [])
jar=args.jar.resolve();root=Path(__file__).resolve().parents[1]
with ZipFile(jar) as z:pack=z.read('graphics/HomeCraft-Warcraft32-26.3-R18.zip');metadata=json.loads(z.read('graphics/bundled.json'))
sha=hashlib.sha256(pack).hexdigest();results=[]
def passed(name):results.append(name);print('PASS',name,flush=True)
def cli(*params,ok=True):
    r=subprocess.run(['java',*java_options,'-Djava.awt.headless=true','-jar',str(jar),*map(str,params)],text=True,capture_output=True,timeout=180)
    if (r.returncode==0)!=ok:raise AssertionError((params,r.returncode,r.stdout,r.stderr))
    return r.stdout+r.stderr
def props(p):
    return dict(line.split('=',1) for line in p.read_text().splitlines() if line and not line.startswith('#') and '='in line)
def new_game(base,name):
    p=base/name;(p/'mods').mkdir(parents=True);(p/'mods/foreign.jar').write_bytes(b'untouched');(p/'options.txt').write_text('music:0.4\nresourcePacks:["vanilla","file/Other.zip"]\ncustom:value\n');return p
def snap(p):return {str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest() for f in p.rglob('*') if f.is_file() and '.homecraft-launcher' not in f.parts}
def fake_mod(id,version):
    b=io.BytesIO()
    with ZipFile(b,'w',ZIP_DEFLATED) as z:
        for name,data in [('META-INF/neoforge.mods.toml',f'[[mods]]\nmodId="{id}"\nversion="{version}"\n'),('assets/data.txt','fixture '+version)]:
            info=ZipInfo(name,date_time=(2020,1,1,0,0,0));info.compress_type=ZIP_DEFLATED;z.writestr(info,data)
    return b.getvalue()
class Server(ThreadingHTTPServer):
    graphics=None;bad_mod_hash=False;mod_version='1.0';corrupt=False
class Handler(BaseHTTPRequestHandler):
    def log_message(self,*args):pass
    def do_GET(self):
        path=urllib.parse.unquote(self.path)
        body=None;content='application/octet-stream'
        ids=['homecraftauth','homecraftchat','homecraftguild','homecraftspawnprotection','realtime']
        files={id+'+mc26.3.jar':fake_mod(id,self.server.mod_version) for id in ids}
        if path=='/api/launcher/manifest':
            entries=[{'id':id,'name':id,'version':self.server.mod_version,'filename':id+'+mc26.3.jar','size':len(files[id+'+mc26.3.jar']),'sha256':('0'*64 if self.server.bad_mod_hash else hashlib.sha256(files[id+'+mc26.3.jar']).hexdigest()),'url':'/client-mods/'+urllib.parse.quote(id+'+mc26.3.jar',safe='')} for id in ids]
            body=json.dumps({'ok':True,'ready':True,'schemaVersion':1,'product':'homecraft','minecraft':'26.3','files':entries}).encode();content='application/json'
        elif path.startswith('/client-mods/'):body=files.get(path.split('/')[-1])
        elif path=='/launcher/graphics-manifest.json' and self.server.graphics is not None:body=json.dumps(self.server.graphics).encode();content='application/json'
        elif path.startswith('/resource-packs/'):
            body=pack if not self.server.corrupt else pack[:30]+bytes([pack[30]^1])+pack[31:]
        if body is None:self.send_error(404);return
        self.send_response(200);self.send_header('Content-Type',content);self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
with TemporaryDirectory(prefix='homecraft-manual-') as temp:
    base=Path(temp);game=new_game(base,'instance');server=Server(('127.0.0.1',0),Handler);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start();site=f'http://127.0.0.1:{server.server_port}'
    try:
        cli('--help');passed('CLI help / Java 17 runtime')
        cli('graphics-install','--game-dir',game,'--offline','--no-renderer')
        name=metadata['filename'];assert hashlib.sha256((game/'shaderpacks'/name).read_bytes()).hexdigest()==sha
        assert (game/'resourcepacks'/name).read_bytes()==pack
        settings=props(game/'shaderpacks'/(name+'.txt'));assert settings['HC_FOREVER_QUALITY']=='1' and settings['SHADOW_CASTING']=='false'
        assert props(game/'config/iris.properties')['shaderPack']==name
        assert 'file/Other.zip' in (game/'options.txt').read_text() and 'custom:value' in (game/'options.txt').read_text()
        assert (game/'mods/foreign.jar').read_bytes()==b'untouched';passed('Offline R18 install: correct folders, Minimum and unrelated files preserved')
        backups=list((game/'.homecraft-launcher/backups').iterdir());before=snap(game)
        cli('graphics-install','--game-dir',game,'--offline','--no-renderer')
        assert snap(game)==before and list((game/'.homecraft-launcher/backups').iterdir())==backups;passed('Repeat installation is idempotent')
        cli('graphics-install','--game-dir',game,'--offline','--no-renderer','--profile','full')
        opts=game/'shaderpacks'/(name+'.txt');settings=props(opts);assert settings['HC_FOREVER_QUALITY']=='2' and settings['AA_TYPE']=='2'
        assert len(list((game/'.homecraft-launcher/backups').iterdir()))>len(backups);passed('Full profile and configuration backups')
        opts.write_text(opts.read_text().replace('HC_FOG_STRENGTH=0.80','HC_FOG_STRENGTH=0.60'))
        iris=game/'config/iris.properties';iris.write_text(iris.read_text().replace('enableShaders=true','enableShaders=false'))
        cli('launch','--site',site,'--game-dir',game,'--launcher-exe','/bin/true','--offline','--no-renderer','--profile','full')
        assert props(opts)['HC_FOG_STRENGTH']=='0.60' and props(iris)['enableShaders']=='false';passed('Automatic preparation preserves manual options and disabled shaders')
        cli('update','--game-dir',game,'--site',site);assert len(list((game/'mods').glob('*.jar')))==6;passed('Five-module installation/updater and encoded + filenames')
        server.mod_version='2.0';cli('update','--game-dir',game,'--site',site);assert (game/'mods/foreign.jar').read_bytes()==b'untouched';passed('Module replacement with backups; foreign mod retained')
        before=snap(game);server.bad_mod_hash=True;server.mod_version='3.0';cli('update','--game-dir',game,'--site',site,ok=False);assert snap(game)==before;server.bad_mod_hash=False;passed('Bad mod hash rejected before any installed file changes')
        remote=dict(metadata,filename='HomeCraft-Warcraft32-26.3-R19.zip',release='R19',url='/resource-packs/HomeCraft-Warcraft32-26.3-R19.zip');server.graphics=remote
        cli('graphics-install','--game-dir',game,'--site',site,'--no-renderer','--profile','full')
        new=remote['filename'];assert (game/'shaderpacks'/new).read_bytes()==pack and not (game/'shaderpacks'/name).exists();assert 'file/'+new in (game/'options.txt').read_text() and 'file/'+name not in (game/'options.txt').read_text();passed('Simulated server release updates both pack destinations and active resource pack')
        cli('graphics-install','--game-dir',game,'--offline','--no-renderer','--profile','full');assert props(game/'.homecraft-launcher/graphics.properties')['release']=='R19';passed('Offline fallback never downgrades a newer verified managed release')
        server.graphics=dict(remote,filename='HomeCraft-Warcraft32-26.3-R20.zip',release='R20',url='/resource-packs/HomeCraft-Warcraft32-26.3-R20.zip',sha256='0'*64)
        before=snap(game);cli('graphics-install','--game-dir',game,'--site',site,'--no-renderer',ok=False);assert snap(game)==before;passed('Bad graphics hash rejected without changing installed files')
        server.graphics=dict(metadata,url='https://other.example/pack.zip');cli('graphics-install','--game-dir',game,'--site',site,'--no-renderer',ok=False);assert snap(game)==before;passed('Cross-origin graphics address rejected')
        broken=new_game(base,'rollback');(broken/'config').write_text('existing file, not directory');before=snap(broken)
        text=cli('graphics-install','--game-dir',broken,'--offline','--no-renderer',ok=False);assert snap(broken)==before;assert 'відновлені' in text;passed('Late commit failure rolls back pack files and options.txt')
        symlinked=new_game(base,'symlink');outside=base/'outside';outside.mkdir();(symlinked/'shaderpacks').symlink_to(outside,target_is_directory=True)
        cli('graphics-install','--game-dir',symlinked,'--offline','--no-renderer',ok=False);assert not list(outside.iterdir());passed('Symlink destination refused')
        lock=game/'.homecraft-launcher/update.lock'
        with lock.open('a') as f:
            fcntl.lockf(f,fcntl.LOCK_EX|fcntl.LOCK_NB);cli('graphics-install','--game-dir',game,'--offline','--no-renderer',ok=False)
        passed('Concurrent update lock respected')
        if args.online_renderers:
            server.graphics=None;online=new_game(base,'renderer');cli('graphics-install','--game-dir',online,'--site',site,'--profile','minimum')
            installed=list((online/'mods').glob('*.jar'));assert len(installed)==3
            with ZipFile(jar) as z:renderers=json.loads(z.read('graphics/renderers.json'))
            for mod in renderers['files']:assert hashlib.sha512((online/'mods'/mod['filename']).read_bytes()).hexdigest()==mod['sha512']
            text=cli('graphics-check','--game-dir',online);assert 'Iris: true' in text and 'Sodium: true' in text;passed('Actual official Iris/Sodium downloads: pinned SHA-512, JAR metadata and install')
            cli('graphics-install','--game-dir',online,'--offline','--profile','full');passed('Already verified renderer pair works fully offline')
    finally:server.shutdown();server.server_close()
report={'status':'PASS','checks':results,'count':len(results),'online_renderer_downloads_tested':args.online_renderers,'minecraft_launched':False,'native_windows_tested':False,'java':'17','fixtures':'Disposable local profiles and local HTTP mock; /bin/true used only for external-launch handoff.'}
(root/'VALIDATION.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report,ensure_ascii=False,indent=2))
