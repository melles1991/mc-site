package ua.homecraft.launcher;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.nio.file.*;
import java.util.*;
import java.util.List;

/** Manual headless Swing layout/action checks; never run by build scripts. */
public class GuiSmoke {
    static void require(boolean condition,String name){if(!condition)throw new AssertionError(name);}
    static List<Component> tree(Container c){List<Component> result=new ArrayList<>();for(Component x:c.getComponents()){result.add(x);if(x instanceof Container n)result.addAll(tree(n));}return result;}
    public static void main(String[] args) throws Exception {
        List<String> checks=new ArrayList<>();
        SwingUtilities.invokeAndWait(()->{
            try {
                HomeCraftLauncher.setupTheme();Properties p=new Properties();p.setProperty("site","https://homecraft-mc.pp.ua");p.setProperty("game",Path.of(System.getProperty("user.home"),".minecraft").toString());p.setProperty("animations","false");
                LauncherUI view=new LauncherUI(p,true);
                for(Dimension size:List.of(new Dimension(1120,760),new Dimension(850,640))) {
                    view.setSize(size);
                    for(String page:List.of("play","graphics","settings","mods","log")) {
                        view.navigate(page);HomeCraftLauncher.layout(view);HomeCraftLauncher.layout(view);
                        BufferedImage image=new BufferedImage(size.width,size.height,BufferedImage.TYPE_INT_RGB);Graphics2D g=image.createGraphics();view.paint(g);g.dispose();
                        for(Component x:tree(view))if(x instanceof JScrollPane scroll&&scroll.isVisible()&&scroll.getViewport().getView() instanceof Scrollable content&&content.getScrollableTracksViewportWidth())
                            require(scroll.getViewport().getView().getWidth()<=scroll.getViewport().getExtentSize().width,"Horizontal clipping: "+page+size);
                        checks.add(page+" renders at "+size.width+"x"+size.height);
                    }
                }
                view.navigate("mods");HomeCraftLauncher.layout(view);
                require(tree(view).stream().anyMatch(x->x instanceof JButton b&&b.getText().equals("Встановити / оновити")),"Missing installation button");checks.add("Missing-mod installation action is visible");
                require(tree(view).stream().anyMatch(x->x instanceof JTextArea t&&t.getText().contains("Chat")&&t.getText().contains("Realtime")),"Missing five-mod description");checks.add("All five client modules are described");
                view.navigate("graphics");HomeCraftLauncher.layout(view);
                JButton full=tree(view).stream().filter(x->x instanceof JButton b&&b.getText().equals("Обрати")).map(x->(JButton)x).findFirst().orElseThrow();full.doClick();
                require("full".equals(HomeCraftUpdater.loadSettings().getProperty("graphicsProfile")),"Full selection persisted");checks.add("Profile card action saves Full choice");
                JButton minimum=tree(view).stream().filter(x->x instanceof JButton b&&b.getText().equals("Обрати")).map(x->(JButton)x).findFirst().orElseThrow();minimum.doClick();
                require("minimum".equals(HomeCraftUpdater.loadSettings().getProperty("graphicsProfile")),"Minimum selection persisted");checks.add("Profile card action saves Minimum choice");
                view.stop();
                Map<String,Object> report=new LinkedHashMap<>();report.put("status","PASS");report.put("checks",checks);report.put("native_windows_tested",false);report.put("method","Actual Swing components/actions rendered headlessly; no game launched.");
                Files.writeString(Path.of(args[0]),Json.stringify(report)+"\n");
            }catch(Exception e){throw new RuntimeException(e);}
        });
        System.out.println("Swing checks passed: "+checks.size());
    }
}
