# HomeCraft Launcher 3.1 — вихідний код

Версія на основі прикріпленого Launcher 3.0, зі збереженим інтерфейсом і графічним пакетом R18.

Клієнтський набір містить 5 модів: Auth, Chat, Guild, Spawn Protection і Realtime. `update` встановлює відсутні файли, оновлює старі й прибирає дублікати керованих модів із резервною копією. `launch` та кнопка «Грати» спочатку забезпечують повний комплект модів через сайт. Неповний/небезпечний маніфест або пошкоджений JAR не допускаються до встановлення. Map до клієнта не завантажується.

Збірка з JDK 17+:

- Linux: `sh build-linux.sh`
- Windows: `build-windows.bat`

Білд створює `HomeCraftLauncher.jar` (Java class major 61). Тести не запускаються автоматично.

Linux: `sh start-linux.sh` або `java -jar HomeCraftLauncher.jar`. Запуск скрипта підтримує JAVA_HOME, параметри CLI та шляхи з пробілами. Windows: `start-windows.bat`. Налаштування папки інстансу та зовнішнього Minecraft/Prism Launcher зберігаються тим самим способом, що в 3.0.

Сайт має надати `/api/launcher/manifest` із п'ятьма modId та актуальні JAR за `/client-mods/...`. Готовий сайт R5.19.2 вже містить ці файли й публікує лаунчер за `/launcher/HomeCraftLauncher.jar` та `/launcher/HomeCraft-Launcher-Java.zip`.

Ручні перевірки після збірки:

```sh
python3 tests/manual_integration.py
python3 tests/check_client_delivery_manual.py --site-dir /шлях/до/website --launcher-dir .
javac --release 17 -encoding UTF-8 -cp build/classes -d build/manual-tests tests/GuiSmoke.java
java -Djava.awt.headless=true -Duser.home=/тимчасова/папка -cp build/classes:build/manual-tests ua.homecraft.launcher.GuiSmoke GUI_VALIDATION.json
```

Перша програма перевіряє локальний HTTP-фікстурний сервер та інсталятор модів/графіки. Друга — реальний Node-код сайту, Linux-скрипт і завантаження всіх п'яти справжніх JAR у тимчасові профілі. Swing перевіряється headless; Minecraft і нативне вікно Windows не запускалися. Поточні звіти — DELIVERY_VALIDATION.json, GUI_VALIDATION.json та VALIDATION.json. Старі previews походять із базової версії 3.0.
