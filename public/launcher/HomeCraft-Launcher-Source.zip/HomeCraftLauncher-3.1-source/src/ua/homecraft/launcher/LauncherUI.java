package ua.homecraft.launcher;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.nio.file.*;
import java.util.*;
import java.util.List;
import java.util.concurrent.*;
import static ua.homecraft.launcher.HomeCraftUpdater.*;

/** Native, dependency-free fantasy interface. Network and installation work run off the EDT. */
final class LauncherUI extends JPanel {
    static final Color BG=new Color(8,21,25),CARD=new Color(16,37,42),LINE=new Color(39,66,68),GOLD=new Color(219,184,112),TEXT=new Color(235,234,221),MUTED=new Color(148,170,166),TEAL=new Color(102,205,181),RED=new Color(239,140,127);
    private final Properties settings;
    private final CardLayout pages=new CardLayout();
    private final JPanel deck=new JPanel(pages);
    private final List<JComponent> controls=new ArrayList<>();
    private final Map<String,Button> navigation=new LinkedHashMap<>();
    private final JTextField site,game,launcher,instance;
    private final JCheckBox allowHttp,autoGraphics,renderer,textures,animations;
    private final JTextArea log=new JTextArea(),status=new JTextArea("Готовий до пригод.",2,30);
    private final JProgressBar progress=new JProgressBar();
    private final JLabel graphicsState=label("Перевірка локальних файлів…",13,MUTED),rendererState=label("Iris + Sodium · NeoForge 26.3",13,MUTED);
    private final JLabel homeGraphics=label("R18 · Мінімальний",18,TEXT),homeModules=label("Ще не перевірені",18,TEXT),profileBadge=label("Мінімальний · R18",12,GOLD);
    private final DefaultTableModel mods=new DefaultTableModel(new String[]{"МОДУЛЬ","ВСТАНОВЛЕНО","НА САЙТІ","СТАН"},0){public boolean isCellEditable(int r,int c){return false;}};
    private final Portal hero=new Portal();
    private final ProfileCard minimum,full;
    private String profile;
    private String localRelease="R18";
    volatile boolean running;
    private boolean active=true;
    LauncherUI(Properties settings,boolean preview) {
        this.settings=settings;profile=settings.getProperty("graphicsProfile","minimum");
        if(!Set.of("minimum","full").contains(profile))profile="minimum";
        site=field(settings.getProperty("site","https://homecraft-mc.pp.ua"));game=field(settings.getProperty("game",defaultGame().toString()));
        launcher=field(settings.getProperty("launcher",""));instance=field(settings.getProperty("instance",""));
        allowHttp=check("Дозволити HTTP у довіреній локальній мережі","allowHttp",false);
        autoGraphics=check("Оновлювати графіку перед запуском","autoGraphics",true);
        renderer=check("Встановити сумісні Iris + Sodium для NeoForge 26.3","installRenderer",true);
        textures=check("Також встановити й увімкнути текстури Warcraft 32×","installTextures",true);
        animations=check("Плавні анімації інтерфейсу","animations",true);
        Button.motion=animations.isSelected();hero.motion=animations.isSelected();
        setLayout(new BorderLayout(20,0));setBackground(BG);setBorder(new EmptyBorder(20,20,20,20));
        add(sidebar(),BorderLayout.WEST);
        JPanel main=column();JPanel body=transparent(new BorderLayout(0,18));body.add(header(),BorderLayout.NORTH);body.add(deck,BorderLayout.CENTER);body.add(footer(),BorderLayout.SOUTH);main.add(body);add(body,BorderLayout.CENTER);
        deck.setOpaque(false);
        deck.add(playPage(),"play");
        minimum=new ProfileCard("minimum","Мінімальний","ЛЕГКИЙ І АТМОСФЕРНИЙ","Для слабких ПК","Прості хвилі й відбиття\nЛегка димка та сяйво\nБез SSAO, TAA і карти тіней");
        full=new ProfileCard("full","Повний","БІЛЬШЕ ГЛИБИНИ Й СВІТЛА","Для вищої якості","М’які тіні та SSR-відбиття\nОб’ємні хмари й промені\nSSAO, TAA та рухомий туман");
        deck.add(graphicsPage(),"graphics");deck.add(modsPage(),"mods");deck.add(settingsPage(),"settings");deck.add(logPage(),"log");
        selectProfile(profile);navigate("play");
        log.setEditable(false);log.setFont(new Font(Font.MONOSPACED,Font.PLAIN,12));log.setBackground(new Color(7,18,22));log.setForeground(MUTED);log.setMargin(new Insets(14,14,14,14));
        if(preview){graphicsState.setText("Готовий до встановлення · пакет R18 вбудовано");rendererState.setText("Iris 1.11.7 + Sodium 0.9.2 · NeoForge 26.3");}
        else refreshLocal();
    }
    private JPanel sidebar() {
        JPanel side=column();side.setPreferredSize(new Dimension(184,600));side.setBorder(new EmptyBorder(4,0,0,12));
        JPanel brand=transparent(new BorderLayout(0,9));brand.add(new Sigil(),BorderLayout.NORTH);
        JLabel name=label("HOMECRAFT",19,GOLD);name.setFont(new Font(Font.SERIF,Font.BOLD,19));brand.add(name,BorderLayout.CENTER);brand.add(label("ТВОЯ ІСТОРІЯ. ТВІЙ СВІТ.",9,MUTED),BorderLayout.SOUTH);brand.setPreferredSize(new Dimension(172,126));brand.setMaximumSize(new Dimension(172,126));side.add(brand);side.add(Box.createVerticalStrut(34));
        String[][] links={{"play","Грати"},{"graphics","Графіка"},{"mods","Модулі"},{"settings","Налаштування"},{"log","Журнал"}};
        for(String[] n:links){Button b=new Button(n[1],false);b.nav=true;b.setHorizontalAlignment(SwingConstants.LEFT);b.setMaximumSize(new Dimension(180,43));b.addActionListener(e->navigate(n[0]));navigation.put(n[0],b);side.add(b);side.add(Box.createVerticalStrut(7));}
        side.add(Box.createVerticalGlue());side.add(label("JAVA LAUNCHER",10,MUTED));side.add(Box.createVerticalStrut(5));side.add(label("v"+VERSION+"  /  26.3",12,GOLD));side.add(Box.createVerticalStrut(8));
        return side;
    }
    private JPanel header() {
        JPanel p=transparent(new BorderLayout());p.add(label("ЛАСКАВО ПРОСИМО ДО HOMECRAFT",11,MUTED),BorderLayout.WEST);
        JLabel badge=label("NEOFORGE  ·  26.3",11,TEAL);badge.setBorder(new CompoundBorder(new LineBorder(LINE),new EmptyBorder(7,12,7,12)));p.add(badge,BorderLayout.EAST);return p;
    }
    private JComponent playPage() {
        JPanel page=column();hero.setLayout(new BorderLayout());hero.setPreferredSize(new Dimension(700,276));hero.setMaximumSize(new Dimension(Integer.MAX_VALUE,276));hero.setBorder(new EmptyBorder(28,27,24,24));
        JPanel words=column();words.setOpaque(false);words.setPreferredSize(new Dimension(345,220));
        words.add(label("WARCRAFT 32×  /  FOREVER ATMOSPHERE",10,TEAL));words.add(Box.createVerticalStrut(15));
        JLabel title=new JLabel("<html>Повернись<br>до пригод.</html>");title.setFont(new Font(Font.SERIF,Font.BOLD,38));title.setForeground(TEXT);words.add(title);words.add(Box.createVerticalStrut(12));words.add(label("Нові обрії. Знайомий світ.",14,MUTED));words.add(Box.createVerticalGlue());words.add(profileBadge);hero.add(words,BorderLayout.WEST);page.add(hero);page.add(Box.createVerticalStrut(16));
        JPanel cards=transparent(new GridLayout(1,2,14,0));cards.setMaximumSize(new Dimension(Integer.MAX_VALUE,135));
        Surface module=new Surface();module.setLayout(new BorderLayout(0,9));module.add(label("КЛІЄНТСЬКІ МОДУЛІ",10,MUTED),BorderLayout.NORTH);module.add(homeModules,BorderLayout.CENTER);
        Button check=button("Перевірити модулі",false,()->modsWork(false));module.add(check,BorderLayout.SOUTH);cards.add(module);
        Surface visual=new Surface();visual.setLayout(new BorderLayout(0,9));visual.add(label("АТМОСФЕРА HOMECRAFT",10,MUTED),BorderLayout.NORTH);visual.add(homeGraphics,BorderLayout.CENTER);visual.add(button("Налаштувати графіку",false,()->navigate("graphics")),BorderLayout.SOUTH);cards.add(visual);page.add(cards);page.add(Box.createVerticalStrut(15));
        page.add(note("Вибери папку свого ігрового інстансу в налаштуваннях. Перед встановленням модів або графіки закрий Minecraft."));return scroll(page);
    }
    private JComponent graphicsPage() {
        JPanel page=column();page.add(title("Атмосфера твого світу",26));page.add(Box.createVerticalStrut(7));page.add(note("Два профілі. Один цілісний стиль. Обери якість під свій ПК."));page.add(Box.createVerticalStrut(18));
        JPanel choices=transparent(new GridLayout(1,2,14,0));choices.add(minimum);choices.add(full);choices.setMaximumSize(new Dimension(Integer.MAX_VALUE,265));choices.setMinimumSize(new Dimension(0,265));choices.setPreferredSize(new Dimension(700,265));page.add(choices);page.add(Box.createVerticalStrut(16));
        Surface install=new Surface();install.setLayout(new BoxLayout(install,BoxLayout.Y_AXIS));
        install.add(graphicsState);install.add(Box.createVerticalStrut(7));install.add(rendererState);install.add(Box.createVerticalStrut(12));install.add(textures);install.add(renderer);install.add(autoGraphics);install.add(Box.createVerticalStrut(12));
        install.add(button("Встановити графіку",true,()->graphicsWork(false)));page.add(install);page.add(Box.createVerticalStrut(12));page.add(note("Повний профіль вимогливіший. Установлення перевіряє файли й створює резервну копію. Вхід у Microsoft залишається у твоєму Minecraft / Prism Launcher."));return scroll(page);
    }
    private JComponent modsPage() {
        JPanel page=transparent(new BorderLayout(0,16));JPanel intro=column();intro.add(title("Модулі HomeCraft",26));intro.add(Box.createVerticalStrut(8));intro.add(note("Auth, Chat, Guild, Spawn Protection і Realtime. Встановлення відсутніх та оновлення старих JAR."));page.add(intro,BorderLayout.NORTH);
        JTable table=new JTable(mods);table.setRowHeight(39);table.setFillsViewportHeight(true);table.setBackground(CARD);table.setForeground(TEXT);table.setGridColor(LINE);table.setSelectionBackground(new Color(34,66,66));table.setShowVerticalLines(false);table.setFont(new Font(Font.DIALOG,Font.PLAIN,12));
        table.getTableHeader().setFont(new Font(Font.DIALOG,Font.BOLD,10));table.getTableHeader().setBackground(CARD);table.getTableHeader().setForeground(MUTED);table.getTableHeader().setPreferredSize(new Dimension(600,36));
        table.setDefaultRenderer(Object.class,new DefaultTableCellRenderer(){public Component getTableCellRendererComponent(JTable t,Object value,boolean selected,boolean focus,int row,int col){super.getTableCellRendererComponent(t,value,selected,focus,row,col);putClientProperty("html.disable",Boolean.TRUE);setBorder(new EmptyBorder(4,10,4,10));if(!selected){setBackground(CARD);setForeground(col==3?TEAL:TEXT);}return this;}});
        JScrollPane pane=new JScrollPane(table);pane.setBorder(new LineBorder(LINE));pane.getViewport().setBackground(CARD);page.add(pane,BorderLayout.CENTER);
        JPanel buttons=transparent(new FlowLayout(FlowLayout.LEFT,0,0));buttons.add(button("Перевірити",false,()->modsWork(false)));buttons.add(Box.createHorizontalStrut(10));buttons.add(button("Встановити / оновити",true,()->modsWork(true)));page.add(buttons,BorderLayout.SOUTH);return page;
    }
    private JComponent settingsPage() {
        JPanel page=column();page.add(title("Твій ігровий простір",26));page.add(Box.createVerticalStrut(8));page.add(note("Вкажи саме папку інстансу, у якій лежать mods та options.txt."));page.add(Box.createVerticalStrut(18));
        Surface form=new Surface();form.setLayout(new BoxLayout(form,BoxLayout.Y_AXIS));
        form.add(formRow("Адреса сайту HomeCraft",site,null));form.add(formRow("Папка ігрового інстансу",game,()->browse(game,true)));form.add(formRow("Minecraft / Prism Launcher",launcher,()->browse(launcher,false)));form.add(formRow("Prism ID · необов’язково",instance,null));
        form.add(Box.createVerticalStrut(5));form.add(allowHttp);form.add(animations);form.add(Box.createVerticalStrut(14));form.add(button("Зберегти налаштування",true,()->{try{save();message("Налаштування збережені.",false);refreshLocal();}catch(Exception e){failure(e);}}));page.add(form);page.add(Box.createVerticalStrut(12));page.add(note("Лаунчер працює на Java 17+. Java для самої гри налаштовується окремо в Minecraft / Prism. Логіни та паролі цей застосунок не збирає."));return scroll(page);
    }
    private JComponent logPage() {
        JPanel page=transparent(new BorderLayout(0,16));page.add(title("Журнал подій",26),BorderLayout.NORTH);JScrollPane pane=new JScrollPane(log);pane.setBorder(new LineBorder(LINE));page.add(pane,BorderLayout.CENTER);page.add(button("Очистити журнал",false,()->log.setText("")),BorderLayout.SOUTH);return page;
    }
    private JPanel footer() {
        JPanel footer=transparent(new BorderLayout(0,10));progress.setPreferredSize(new Dimension(100,3));progress.setForeground(TEAL);progress.setBackground(LINE);progress.setBorderPainted(false);footer.add(progress,BorderLayout.NORTH);
        JPanel line=transparent(new BorderLayout(12,0));status.setFont(new Font(Font.DIALOG,Font.PLAIN,12));status.setForeground(MUTED);status.setOpaque(false);status.setEditable(false);status.setFocusable(false);status.setLineWrap(true);status.setWrapStyleWord(true);line.add(status,BorderLayout.CENTER);
        Button play=button("Грати  →",true,()->graphicsWork(true));play.setPreferredSize(new Dimension(177,49));line.add(play,BorderLayout.EAST);footer.add(line,BorderLayout.CENTER);return footer;
    }
    private JPanel formRow(String name,JTextField field,Runnable browse) {
        JPanel block=column();block.setOpaque(false);block.add(label(name,12,MUTED));block.add(Box.createVerticalStrut(7));JPanel row=transparent(new BorderLayout(9,0));row.add(field,BorderLayout.CENTER);if(browse!=null)row.add(button("Огляд…",false,browse),BorderLayout.EAST);row.setMaximumSize(new Dimension(Integer.MAX_VALUE,38));row.setPreferredSize(new Dimension(600,38));block.add(row);block.add(Box.createVerticalStrut(15));return block;
    }
    private JTextField field(String value){JTextField f=new JTextField(value);f.setFont(new Font(Font.DIALOG,Font.PLAIN,13));f.setBackground(new Color(9,25,29));f.setForeground(TEXT);f.setCaretColor(TEAL);f.setBorder(new CompoundBorder(new LineBorder(LINE),new EmptyBorder(8,10,8,10)));controls.add(f);return f;}
    private JCheckBox check(String text,String key,boolean fallback) {
        JCheckBox c=new JCheckBox(text,Boolean.parseBoolean(settings.getProperty(key,Boolean.toString(fallback))));c.setOpaque(false);c.setForeground(TEXT);c.setFont(new Font(Font.DIALOG,Font.PLAIN,12));c.setIcon(new CheckIcon());c.setFocusPainted(true);c.setBorder(new EmptyBorder(5,0,5,0));c.setAlignmentX(LEFT_ALIGNMENT);controls.add(c);
        c.addActionListener(e->{settings.setProperty(key,Boolean.toString(c.isSelected()));if(key.equals("animations")){Button.motion=c.isSelected();hero.motion=c.isSelected();hero.updateTimer();}try{save();}catch(Exception ex){failure(ex);}});return c;
    }
    private Button button(String text,boolean primary,Runnable action){Button b=new Button(text,primary);b.addActionListener(e->action.run());controls.add(b);return b;}
    void navigate(String name){pages.show(deck,name);navigation.forEach((key,b)->{b.selected=key.equals(name);b.repaint();});hero.updateTimer();}
    private void selectProfile(String value){profile=value;settings.setProperty("graphicsProfile",value);if(minimum!=null)minimum.refresh();if(full!=null)full.refresh();String name=value.equals("full")?"Повний":"Мінімальний";profileBadge.setText(name+" · "+localRelease);homeGraphics.setText(localRelease+" · "+name);}
    private void browse(JTextField target,boolean directory){JFileChooser c=new JFileChooser();c.setFileSelectionMode(directory?JFileChooser.DIRECTORIES_ONLY:JFileChooser.FILES_ONLY);try{Path p=Path.of(target.getText());if(Files.isDirectory(p))c.setCurrentDirectory(p.toFile());}catch(Exception ignored){}if(c.showOpenDialog(this)==JFileChooser.APPROVE_OPTION){target.setText(c.getSelectedFile().toString());try{save();refreshLocal();}catch(Exception e){failure(e);}}}
    private void save() throws Exception {settings.setProperty("site",site.getText().trim());settings.setProperty("game",game.getText().trim());settings.setProperty("launcher",launcher.getText().trim());settings.setProperty("instance",instance.getText().trim());settings.setProperty("graphicsProfile",profile);saveSettings(settings);}
    private void append(String value){if(!SwingUtilities.isEventDispatchThread()){SwingUtilities.invokeLater(()->append(value));return;}log.append(value+"\n");if(log.getDocument().getLength()>180000)log.replaceRange("",0,50000);log.setCaretPosition(log.getDocument().getLength());}
    private void message(String value,boolean error){status.setText(value);status.setForeground(error?RED:MUTED);status.setToolTipText(value);}
    private void failure(Throwable ex){String text=ex.getMessage()==null?ex.toString():ex.getMessage();append("ПОМИЛКА · "+text);message(text,true);}
    private void refreshLocal(){Path folder;try{folder=Path.of(game.getText());}catch(Exception e){graphicsState.setText("Обери коректну папку інстансу.");return;}new SwingWorker<GraphicsInstaller.Status,Void>(){protected GraphicsInstaller.Status doInBackground(){return GraphicsInstaller.status(folder);}protected void done(){try{var s=get();var match=java.util.regex.Pattern.compile("-R([0-9]+)").matcher(s.pack());if(match.find()){localRelease="R"+match.group(1);selectProfile(profile);}graphicsState.setText(s.shaderInstalled()?("Пак встановлено · "+(s.enabled()?"шейдери ввімкнені":"шейдери вимкнені")):"Пак не встановлено · R18 вбудовано в лаунчер");rendererState.setText("Iris: "+(s.iris()?"встановлено":"немає")+"   /   Sodium: "+(s.sodium()?"встановлено":"немає"));}catch(Exception e){graphicsState.setText("Не вдалося перевірити локальні файли.");}}}.execute();}
    private void setBusy(boolean busy,String text){running=busy;controls.forEach(c->c.setEnabled(!busy));progress.setIndeterminate(busy);if(text!=null)message(text,false);}
    private void modsWork(boolean install){
        if(running)return;try{save();}catch(Exception e){failure(e);return;}String address=site.getText().trim();Path folder;try{folder=Path.of(game.getText().trim()).toAbsolutePath().normalize();}catch(Exception e){failure(e);return;}boolean http=allowHttp.isSelected();
        setBusy(true,install?"Встановлення й оновлення 5 модів… Minecraft має бути закритим.":"Перевірка модулів на сайті…");
        new SwingWorker<Result,Void>(){protected Result doInBackground() throws Exception {HomeCraftUpdater u=new HomeCraftUpdater(LauncherUI.this::append);return install?u.update(address,folder,http):u.check(address,folder,http);}protected void done(){setBusy(false,null);try{Result r=get();mods.setRowCount(0);for(Row row:r.rows())mods.addRow(new Object[]{row.remote().name(),row.installed().isEmpty()?"—":localVersion(row.installed().get(0)),row.remote().version(),row.status()});long ready=r.rows().stream().filter(Row::current).count();homeModules.setText(ready+" / "+r.rows().size()+" актуальні");message(install?"Оновлено модулів: "+r.updated():"Перевірку модулів завершено.",false);navigate("mods");}catch(Exception e){failure(cause(e));}}}.execute();
    }
    private void graphicsWork(boolean launchGame){
        if(running)return;
        try{save();}catch(Exception e){failure(e);return;}
        String address=site.getText().trim(),chosen=profile,exe=launcher.getText().trim(),id=instance.getText().trim();
        Path folder;
        try{folder=Path.of(game.getText().trim()).toAbsolutePath().normalize();}catch(Exception e){failure(e);return;}
        boolean http=allowHttp.isSelected(),withRenderer=renderer.isSelected(),withTextures=textures.isSelected(),prepare=!launchGame||autoGraphics.isSelected();
        Properties launchSettings=new Properties();launchSettings.putAll(settings);
        setBusy(true,launchGame?"Перевірка та встановлення модів перед запуском…":"Підготовка графіки… Minecraft має бути закритим.");
        new SwingWorker<GraphicsInstaller.Installed,Void>(){
            private Result modulesResult;
            protected GraphicsInstaller.Installed doInBackground() throws Exception {
                if(launchGame)modulesResult=HomeCraftLauncher.prepareClientModules(launchSettings,LauncherUI.this::append);
                GraphicsInstaller.Installed result=prepare?new GraphicsInstaller(LauncherUI.this::append).install(address,folder,http,chosen,withRenderer,withTextures,false,!launchGame):null;
                if(launchGame)HomeCraftLauncher.launchExternal(exe,id);
                return result;
            }
            protected void done(){
                setBusy(false,null);
                try{
                    var result=get();
                    if(modulesResult!=null){
                        mods.setRowCount(0);
                        for(Row row:modulesResult.rows())mods.addRow(new Object[]{row.remote().name(),row.installed().isEmpty()?"—":localVersion(row.installed().get(0)),row.remote().version(),row.status()});
                        homeModules.setText(modulesResult.rows().stream().filter(Row::current).count()+" / "+modulesResult.rows().size()+" актуальні");
                    }
                    message(launchGame?"Моди готові. Зовнішній лаунчер запущено.":result!=null&&!result.rendererReady()?"Пак установлено. Для відображення потрібні Iris і Sodium.":"Графіку встановлено. Можна запускати гру.",false);
                    if(result!=null){localRelease=result.release();profileBadge.setText((chosen.equals("full")?"Повний":"Мінімальний")+" · "+localRelease);homeGraphics.setText(result.release()+" · "+(chosen.equals("full")?"Повний":"Мінімальний"));}
                    refreshLocal();
                }catch(Exception e){failure(cause(e));}
            }
        }.execute();
    }
    private static Throwable cause(Exception e){if(e instanceof InterruptedException)Thread.currentThread().interrupt();return e instanceof ExecutionException&&e.getCause()!=null?e.getCause():e;}
    void active(boolean value){active=value;hero.updateTimer();}
    void stop(){hero.timer.stop();}
    public void paint(Graphics graphics){Graphics2D g=(Graphics2D)graphics.create();quality(g);super.paint(g);g.dispose();}
    private final class ProfileCard extends Surface {
        final String value;final Button choice;
        ProfileCard(String value,String name,String eyebrow,String subtitle,String features){this.value=value;setLayout(new BoxLayout(this,BoxLayout.Y_AXIS));add(label(eyebrow,9,value.equals("full")?GOLD:TEAL));add(Box.createVerticalStrut(12));add(title(name,24));add(Box.createVerticalStrut(7));add(label(subtitle,12,MUTED));add(Box.createVerticalStrut(14));JTextArea details=note(features);details.setForeground(TEXT);add(details);add(Box.createVerticalGlue());choice=button("Обрати",false,()->{selectProfile(value);try{save();}catch(Exception e){failure(e);}});add(choice);}
        void refresh(){selected=value.equals(profile);choice.setText(selected?"Обрано  ✓":"Обрати");choice.selected=selected;repaint();choice.repaint();}
    }
    static JPanel transparent(LayoutManager layout){JPanel p=new JPanel(layout);p.setOpaque(false);return p;}
    static JPanel column(){JPanel p=new Column();p.setLayout(new BoxLayout(p,BoxLayout.Y_AXIS));p.setOpaque(false);p.setAlignmentX(LEFT_ALIGNMENT);return p;}
    private static class Column extends JPanel implements Scrollable {
        protected void addImpl(Component c,Object constraints,int index){if(c instanceof JComponent j)j.setAlignmentX(LEFT_ALIGNMENT);super.addImpl(c,constraints,index);}
        public Dimension getPreferredScrollableViewportSize(){return getPreferredSize();}
        public int getScrollableUnitIncrement(Rectangle visible,int orientation,int direction){return 22;}
        public int getScrollableBlockIncrement(Rectangle visible,int orientation,int direction){return Math.max(22,visible.height-22);}
        public boolean getScrollableTracksViewportWidth(){return true;}
        public boolean getScrollableTracksViewportHeight(){return false;}
    }
    static JLabel label(String text,int size,Color color){JLabel l=new JLabel(text);l.setFont(new Font(Font.DIALOG,Font.PLAIN,size));l.setForeground(color);l.setAlignmentX(LEFT_ALIGNMENT);return l;}
    static JLabel title(String text,int size){JLabel l=label(text,size,TEXT);l.setFont(new Font(Font.SERIF,Font.BOLD,size));return l;}
    static JTextArea note(String text){JTextArea t=new JTextArea(text);t.setFont(new Font(Font.DIALOG,Font.PLAIN,12));t.setForeground(MUTED);t.setOpaque(false);t.setEditable(false);t.setFocusable(false);t.setLineWrap(true);t.setWrapStyleWord(true);t.setAlignmentX(LEFT_ALIGNMENT);t.setBorder(null);return t;}
    static JComponent scroll(JComponent content){JScrollPane s=new JScrollPane(content);s.setBorder(null);s.setOpaque(false);s.getViewport().setOpaque(false);s.getVerticalScrollBar().setUnitIncrement(22);s.getVerticalScrollBar().setUI(new javax.swing.plaf.basic.BasicScrollBarUI(){protected void configureScrollBarColors(){thumbColor=LINE;trackColor=BG;}protected JButton createDecreaseButton(int orientation){JButton b=new JButton();b.setPreferredSize(new Dimension(0,0));return b;}protected JButton createIncreaseButton(int orientation){return createDecreaseButton(orientation);}protected void paintThumb(Graphics graphics,JComponent c,Rectangle r){Graphics2D g=(Graphics2D)graphics.create();quality(g);g.setColor(LINE);g.fillRoundRect(r.x+2,r.y,r.width-4,r.height,5,5);g.dispose();}});s.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);return s;}
    static void quality(Graphics2D g){g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,RenderingHints.VALUE_TEXT_ANTIALIAS_ON);}
    static class Surface extends JPanel {
        boolean selected;
        Surface(){setOpaque(false);setBorder(new EmptyBorder(18,18,18,18));setAlignmentX(LEFT_ALIGNMENT);}
        protected void addImpl(Component c,Object constraints,int index){if(c instanceof JComponent j)j.setAlignmentX(LEFT_ALIGNMENT);super.addImpl(c,constraints,index);}
        protected void paintComponent(Graphics graphics){Graphics2D g=(Graphics2D)graphics.create();quality(g);g.setColor(CARD);g.fillRoundRect(0,0,getWidth()-1,getHeight()-1,15,15);g.setColor(selected?GOLD:LINE);g.drawRoundRect(0,0,getWidth()-1,getHeight()-1,15,15);g.dispose();}
    }
    private static final class CheckIcon implements Icon {
        public int getIconWidth(){return 17;}public int getIconHeight(){return 17;}
        public void paintIcon(Component c,Graphics graphics,int x,int y){Graphics2D g=(Graphics2D)graphics.create();quality(g);g.translate(x,y);boolean checked=c instanceof AbstractButton b&&b.isSelected();g.setColor(checked?new Color(29,70,64):BG);g.fillRoundRect(0,0,15,15,4,4);g.setColor(checked?TEAL:LINE);g.drawRoundRect(0,0,15,15,4,4);if(checked){g.setStroke(new BasicStroke(1.7f));g.drawLine(3,8,6,11);g.drawLine(6,11,12,4);}g.dispose();}
    }
    static final class Button extends JButton {
        static boolean motion=true;
        boolean selected,nav;final boolean primary;float hover=0,target=0;
        final javax.swing.Timer timer=new javax.swing.Timer(16,e->{hover+=(target-hover)*0.28f;if(Math.abs(target-hover)<0.015){hover=target;((javax.swing.Timer)e.getSource()).stop();}repaint();});
        Button(String text,boolean primary){super(text);this.primary=primary;setFont(new Font(Font.DIALOG,Font.BOLD,12));setForeground(primary?BG:TEXT);setBorder(new EmptyBorder(11,17,11,17));setContentAreaFilled(false);setFocusPainted(false);setOpaque(false);setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));setAlignmentX(LEFT_ALIGNMENT);addMouseListener(new MouseAdapter(){public void mouseEntered(MouseEvent e){animate(1);}public void mouseExited(MouseEvent e){animate(0);}});addFocusListener(new FocusAdapter(){public void focusGained(FocusEvent e){repaint();}public void focusLost(FocusEvent e){repaint();}});}
        private void animate(float to){target=to;if(motion)timer.start();else{hover=to;repaint();}}
        protected void paintComponent(Graphics graphics){Graphics2D g=(Graphics2D)graphics.create();quality(g);int w=getWidth()-1,h=getHeight()-1;Color base=primary?GOLD:selected?new Color(30,63,61):new Color(20,46,51);if(!isEnabled())base=primary?new Color(95,91,70):new Color(19,34,37);g.setColor(base);g.fillRoundRect(0,0,w,h,10,10);if(hover>0&&isEnabled()){g.setColor(new Color(255,244,209,(int)(hover*(primary?24:13))));g.fillRoundRect(0,0,w,h,10,10);}g.setColor(selected?GOLD:isFocusOwner()?TEAL:primary?new Color(236,210,151):LINE);g.drawRoundRect(0,0,w,h,10,10);if(nav&&selected){g.setColor(GOLD);g.fillRoundRect(0,11,3,h-22,3,3);}if(isFocusOwner()){g.setColor(TEAL);g.drawRoundRect(2,2,w-4,h-4,8,8);}g.setFont(getFont());g.setColor(isEnabled()?(primary?BG:TEXT):MUTED);FontMetrics f=g.getFontMetrics();int x=getHorizontalAlignment()==SwingConstants.LEFT?17:(getWidth()-f.stringWidth(getText()))/2;g.drawString(getText(),x,(getHeight()-f.getHeight())/2+f.getAscent()+(getModel().isPressed()?1:0));g.dispose();}
        public void removeNotify(){timer.stop();super.removeNotify();}
    }
    private static final class Sigil extends JComponent {
        Sigil(){setPreferredSize(new Dimension(70,65));}
        protected void paintComponent(Graphics graphics){Graphics2D g=(Graphics2D)graphics.create();quality(g);g.translate(27,29);g.setStroke(new BasicStroke(1.2f));g.setColor(GOLD);Path2D d=new Path2D.Double();d.moveTo(0,-25);d.lineTo(23,0);d.lineTo(0,25);d.lineTo(-23,0);d.closePath();g.draw(d);g.setColor(TEAL);g.setStroke(new BasicStroke(2.2f));g.drawLine(-8,-11,-8,11);g.drawLine(8,-11,8,11);g.drawLine(-8,0,8,0);g.dispose();}
    }
    private final class Portal extends JPanel {
        boolean motion=true;BufferedImage cache;double phase=0;
        final javax.swing.Timer timer=new javax.swing.Timer(50,e->{phase=(phase+0.05)%16.0;repaint(Math.max(0,getWidth()-390),0,390,getHeight());});
        Portal(){setOpaque(false);addHierarchyListener(e->updateTimer());}
        void updateTimer(){if(motion&&active&&isShowing()&&getWidth()>700)timer.start();else timer.stop();}
        protected void paintComponent(Graphics graphics){int w=getWidth(),h=getHeight();if(w<1||h<1)return;if(cache==null||cache.getWidth()!=w||cache.getHeight()!=h){cache=new BufferedImage(w,h,BufferedImage.TYPE_INT_ARGB);Graphics2D b=cache.createGraphics();quality(b);b.setClip(new RoundRectangle2D.Float(0,0,w-1,h-1,17,17));b.setPaint(new GradientPaint(0,0,new Color(13,43,45),w,h,new Color(8,27,35)));b.fillRect(0,0,w,h);int cx=w-175;for(int layer=0;layer<3;layer++){b.setColor(new Color(17+layer*3,48-layer*3,51-layer*2));Path2D land=new Path2D.Double();land.moveTo(w*0.4,h);for(int x=(int)(w*0.4);x<=w+20;x+=20)land.lineTo(x,h*0.38+layer*42+Math.sin(x*.018+layer)*30);land.lineTo(w,h);land.closePath();b.fill(land);}Random r=new Random(318);for(int i=0;i<24;i++){int x=w-340+r.nextInt(370),y=65+r.nextInt(100),height=50+r.nextInt(90);b.setColor(new Color(7,29,32));b.fillRect(x-2,y,4,height);for(int t=0;t<3;t++){int yy=y+t*height/5;b.fillPolygon(new int[]{x-22-t*4,x,x+22+t*4},new int[]{yy+height/2,yy,yy+height/2},3);}}b.setColor(new Color(34,73,70));b.fillOval(cx-60,h-49,120,19);b.setStroke(new BasicStroke(15));b.setColor(new Color(67,81,72));b.draw(new Arc2D.Float(cx-52,40,104,167,0,180,Arc2D.OPEN));b.drawLine(cx-52,122,cx-52,h-51);b.drawLine(cx+52,122,cx+52,h-51);b.setStroke(new BasicStroke(2));b.setColor(new Color(148,140,104));b.draw(new Arc2D.Float(cx-52,40,104,167,0,180,Arc2D.OPEN));b.drawLine(cx-52,122,cx-52,h-51);b.drawLine(cx+52,122,cx+52,h-51);b.setPaint(new GradientPaint((int)(w*.38),0,new Color(13,43,45,255),(int)(w*.62),0,new Color(13,43,45,0)));b.fillRect(0,0,(int)(w*.62),h);b.dispose();}
            Graphics2D g=(Graphics2D)graphics.create();quality(g);g.setClip(new RoundRectangle2D.Float(0,0,w-1,h-1,17,17));g.drawImage(cache,0,0,null);int cx=w-175;float pulse=(float)(0.5+0.5*Math.sin(phase*Math.PI/4));for(int i=5;i>=0;i--){g.setColor(new Color(61,192,167,8+i*3));g.fillOval(cx-31-i*7,70-i*7,62+i*14,140+i*12);}g.setPaint(new GradientPaint(cx,75,new Color(79,207,179,130),cx,h-40,new Color(22,83,90,25)));g.fillOval(cx-40,70,80,h-116);g.setStroke(new BasicStroke(1.2f));g.setColor(new Color(132,232,198,(int)(80+70*pulse)));g.drawOval(cx-31,76,62,h-132);for(int i=0;i<12;i++){double a=i*2.39996+phase*Math.PI/8;int x=cx+(int)(Math.sin(a)*85),y=135+(int)(Math.cos(a+i*.2)*65);g.setColor(new Color(184,227,183,45+(i%4)*30));g.fillOval(x,y,2+i%2,2+i%2);}g.setClip(null);g.setColor(LINE);g.drawRoundRect(0,0,w-1,h-1,17,17);g.dispose();}
        public void removeNotify(){timer.stop();super.removeNotify();}
    }
}
