package ua.homecraft.launcher;

import java.io.*;
import java.net.*;
import java.nio.channels.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.*;
import java.util.*;
import java.util.function.Consumer;
import java.util.zip.*;
import static java.nio.file.StandardCopyOption.*;
import static ua.homecraft.launcher.HomeCraftUpdater.*;

/** Installs a verified resource/shader pack and its pinned NeoForge renderer pair. */
final class GraphicsInstaller {
    static final String PACK_ID="a728c545-31e3-48fa-a16d-5f19c19fc2ef";
    static final long MAX_PACK=64L*1024*1024;
    record Pack(String filename,String release,long size,String sha256,String sha1,URI url,boolean embedded) {}
    record Status(boolean shaderInstalled,boolean iris,boolean sodium,String profile,String pack,boolean enabled) {
        boolean rendererReady(){return iris&&sodium;}
    }
    record Installed(String release,String filename,String profile,boolean rendererReady,Path backup) {}
    private final Consumer<String> log;
    GraphicsInstaller(Consumer<String> log){this.log=log;}
    private static Map<String,Object> bundled(String name) throws IOException {
        try(InputStream in=GraphicsInstaller.class.getResourceAsStream("/graphics/"+name)) {
            if(in==null)throw new IOException("Вбудований файл відсутній: "+name);
            return Json.object(Json.parse(new String(in.readNBytes(262145),StandardCharsets.UTF_8)));
        }
    }
    static Pack bundledPack() throws Exception {return parsePack(bundled("bundled.json"),null,true);}
    private static Pack parsePack(Map<String,Object> m,URI origin,boolean embedded) throws Exception {
        if(Json.integer(m,"schemaVersion")!=1 || !"homecraft-graphics".equals(Json.text(m,"product"))
            || !"26.3".equals(Json.text(m,"minecraft")) || !PACK_ID.equals(Json.text(m,"packId")))
            throw new IOException("Маніфест графіки не відповідає HomeCraft / Minecraft 26.3.");
        String name=Json.text(m,"filename"),hash=Json.text(m,"sha256"),sha1=Json.text(m,"sha1"),release=Json.text(m,"release");
        long size=Json.integer(m,"size");
        if(!name.matches("HomeCraft-Warcraft32-26\\.3-R[0-9]+(?:-[A-Za-z0-9_-]+)?\\.zip")
            || !hash.matches("[a-f0-9]{64}") || !sha1.matches("[a-f0-9]{40}") || size<1 || size>MAX_PACK || !release.matches("R[0-9]+"))
            throw new IOException("Некоректні ім’я, розмір або контрольна сума пакета.");
        String source=Json.text(m,"url");
        if(!source.equals("/resource-packs/"+name))throw new IOException("Графіка має завантажуватися з /resource-packs/ на тому самому сайті.");
        return new Pack(name,release,size,hash,sha1,origin==null?null:origin.resolve(source),embedded);
    }
    Pack resolve(String site,boolean http,boolean offline) throws Exception {
        if(offline)return bundledPack();
        URI origin=baseUri(site,http);
        try {
            byte[] data=readUrl(origin.resolve("launcher/graphics-manifest.json"),262144,true);
            if(data==null){log.accept("На сайті ще немає графічного маніфесту. Використовую вбудований R18.");return bundledPack();}
            return parsePack(Json.object(Json.parse(new String(data,StandardCharsets.UTF_8))),origin,false);
        } catch(java.net.SocketTimeoutException | java.net.ConnectException | java.net.UnknownHostException e) {
            log.accept("Сайт недоступний. Використовую вбудований R18.");return bundledPack();
        }
    }
    private static HttpURLConnection connect(URI uri) throws IOException {
        if(!Set.of("http","https").contains(uri.getScheme()))throw new IOException("Непідтримуваний протокол завантаження.");
        HttpURLConnection c=(HttpURLConnection)uri.toURL().openConnection();c.setConnectTimeout(12000);c.setReadTimeout(20000);
        c.setInstanceFollowRedirects(false);c.setRequestProperty("User-Agent","HomeCraftLauncher/"+VERSION);return c;
    }
    private static byte[] readUrl(URI uri,long limit,boolean optional) throws IOException {
        HttpURLConnection c=connect(uri);
        try {
            int status=c.getResponseCode();if(optional&&status==404)return null;
            if(status!=200)throw new IOException("Сайт повернув HTTP "+status+" для графіки.");
            try(InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()) {
                transfer(in,out,limit);return out.toByteArray();
            }
        } finally {c.disconnect();}
    }
    private static long transfer(InputStream in,OutputStream out,long limit) throws IOException {
        byte[] b=new byte[65536];long total=0;int n;
        while((n=in.read(b))!=-1){if(Thread.currentThread().isInterrupted())throw new InterruptedIOException("Встановлення перервано");total+=n;if(total>limit)throw new IOException("Файл перевищує дозволений розмір");out.write(b,0,n);}return total;
    }
    private void download(URI uri,Path file,long size) throws Exception {
        HttpURLConnection c=connect(uri);
        try {
            if(c.getResponseCode()!=200)throw new IOException("Завантаження не вдалося: HTTP "+c.getResponseCode());
            try(InputStream in=c.getInputStream();OutputStream out=Files.newOutputStream(file,StandardOpenOption.CREATE_NEW)) {
                if(transfer(in,out,size+1)!=size)throw new IOException("Розмір завантаження не збігається.");
            }
        } finally {c.disconnect();}
    }
    private static String digest(Path p,String algorithm) throws Exception {
        MessageDigest d=MessageDigest.getInstance(algorithm);try(InputStream in=Files.newInputStream(p)){byte[] b=new byte[65536];int n;while((n=in.read(b))!=-1)d.update(b,0,n);}return HexFormat.of().formatHex(d.digest());
    }
    private static Properties properties(Path p) throws IOException {
        Properties result=new Properties();if(Files.isRegularFile(p))try(InputStream in=Files.newInputStream(p)){result.load(in);}return result;
    }
    private static byte[] encode(Properties p) throws IOException {
        StringBuilder result=new StringBuilder();
        for(String key:p.stringPropertyNames().stream().sorted().toList()) {
            Properties single=new Properties();single.setProperty(key,p.getProperty(key));ByteArrayOutputStream out=new ByteArrayOutputStream();single.store(out,null);
            for(String l:out.toString(StandardCharsets.ISO_8859_1).split("\\R"))if(!l.startsWith("#"))result.append(l).append('\n');
        }
        return result.toString().getBytes(StandardCharsets.ISO_8859_1);
    }
    static Status status(Path game) {
        boolean iris=false,sodium=false;
        try(var stream=Files.newDirectoryStream(game.resolve("mods"),"*.jar")) {
            for(Path p:stream){String id=modId(p);iris|="iris".equals(id);sodium|="sodium".equals(id);}
        }catch(IOException ignored){}
        try {
            Properties cfg=properties(game.resolve("config/iris.properties"));String pack=cfg.getProperty("shaderPack","");
            boolean valid=pack.matches("[A-Za-z0-9._+-]+\\.zip") && Files.isRegularFile(game.resolve("shaderpacks").resolve(pack));
            Properties opts=valid?properties(game.resolve("shaderpacks").resolve(pack+".txt")):new Properties();
            String profile="2".equals(opts.getProperty("HC_FOREVER_QUALITY"))?"full":"minimum";
            return new Status(valid,iris,sodium,profile,pack,Boolean.parseBoolean(cfg.getProperty("enableShaders","false")));
        }catch(IOException ignored){return new Status(false,iris,sodium,"minimum","",false);}
    }
    private static void noLink(Path root,Path target) throws IOException {
        Path at=root;
        for(Path part:root.relativize(target)){at=at.resolve(part);if(Files.isSymbolicLink(at))throw new IOException("Символічні посилання не підтримуються: "+at.getFileName());}
    }
    static void gameClosed(Path game) throws IOException {
        String selected=game.toAbsolutePath().normalize().toString();
        try(var processes=ProcessHandle.allProcesses()) {
            boolean active=processes.filter(p->p.pid()!=ProcessHandle.current().pid()).map(p->p.info().commandLine().orElse(""))
                .anyMatch(s->s.contains(selected)&&!s.contains("HomeCraftLauncher")&&(s.contains("net.minecraft")||s.contains("cpw.mods")||s.contains("fabricmc.loader")||s.contains("neoforge")));
            if(active)throw new IOException("Minecraft цього інстансу працює. Закрий гру перед встановленням.");
        }catch(SecurityException ignored){}
    }
    private static Properties validatePack(Path file) throws Exception {
        Properties profiles=new Properties();boolean root=false,shaders=false;long total=0;int count=0;Set<String> names=new HashSet<>();
        byte[] buffer=new byte[65536];
        try(ZipFile zip=new ZipFile(file.toFile())) {
            for(var entries=zip.entries();entries.hasMoreElements();) {
                ZipEntry e=entries.nextElement();String n=e.getName();
                if(++count>20000||n.startsWith("/")||n.contains("\\")||Arrays.asList(n.split("/")).contains("..")||!names.add(n))throw new IOException("Некоректний ZIP-пакет.");
                if(e.isDirectory())continue;long length=0;CRC32 crc=new CRC32();
                try(InputStream in=zip.getInputStream(e)){int r;while((r=in.read(buffer))!=-1){length+=r;total+=r;if(total>256L*1024*1024)throw new IOException("Пакет надто великий після розпакування.");crc.update(buffer,0,r);}}
                if(length!=e.getSize()||crc.getValue()!=e.getCrc())throw new IOException("Пошкоджений запис ZIP: "+n);
                root|=n.equals("pack.mcmeta");shaders|=n.equals("shaders/shaders.properties");
            }
            if(!root||!shaders)throw new IOException("ZIP не містить resource pack і shader pack у корені.");
            try(Reader in=new InputStreamReader(zip.getInputStream(zip.getEntry("shaders/shaders.properties")),StandardCharsets.UTF_8)){profiles.load(in);}
            if(profiles.getProperty("profile.minimum")==null||profiles.getProperty("profile.full")==null)throw new IOException("У пакеті немає профілів Minimum / Full.");
        }
        return profiles;
    }
    private static byte[] textureOptions(Path file,String oldName,String newName) throws Exception {
        List<String> lines=Files.exists(file)?new ArrayList<>(Files.readAllLines(file,StandardCharsets.UTF_8)):new ArrayList<>();
        List<String> packs=new ArrayList<>();int index=-1;
        for(int i=0;i<lines.size();i++)if(lines.get(i).startsWith("resourcePacks:")){
            if(index>=0)throw new IOException("Повторний resourcePacks у options.txt");index=i;
            Object value=Json.parse(lines.get(i).substring("resourcePacks:".length()));
            if(!(value instanceof List<?> list))throw new IOException("Некоректний resourcePacks у options.txt");
            for(Object v:list){if(!(v instanceof String s))throw new IOException("Некоректний список ресурспаків");packs.add(s);}
        }
        if(!oldName.isBlank()&&!oldName.equals(newName))packs.remove("file/"+oldName);
        packs.remove("file/"+newName);packs.add("file/"+newName);
        String row="resourcePacks:"+Json.stringify(packs);if(index<0)lines.add(row);else lines.set(index,row);
        return (String.join("\n",lines)+"\n").getBytes(StandardCharsets.UTF_8);
    }
    Installed install(String site,Path game,boolean http,String profile,boolean renderer,boolean textures,boolean offline,boolean explicit) throws Exception {
        if(!Set.of("minimum","full").contains(profile))throw new IOException("Профіль має бути minimum або full.");
        game=game.toAbsolutePath().normalize();validateGame(game);gameClosed(game);
        Path state=game.resolve(".homecraft-launcher");noLink(game,state);Files.createDirectories(state);
        try(FileChannel c=FileChannel.open(state.resolve("update.lock"),StandardOpenOption.CREATE,StandardOpenOption.WRITE);FileLock lock=c.tryLock()) {
            if(lock==null)throw new IOException("Інше оновлення вже працює.");
            noLink(game,state.resolve("graphics.properties"));
            Properties previous=properties(state.resolve("graphics.properties"));String old=previous.getProperty("pack","");
            if(!old.isBlank()&&!old.matches("HomeCraft-Warcraft32-26\\.3-R[0-9]+(?:-[A-Za-z0-9_-]+)?\\.zip"))throw new IOException("Некоректний попередній запис графіки.");
            Pack pack=resolve(site,http,offline);
            String oldRelease=previous.getProperty("release","");
            if(oldRelease.matches("R[0-9]+") && new java.math.BigInteger(oldRelease.substring(1)).compareTo(new java.math.BigInteger(pack.release().substring(1)))>0
                && previous.getProperty("sha256","").matches("[a-f0-9]{64}")) {
                Path newer=game.resolve("shaderpacks").resolve(old);noLink(game,newer);
                if(Files.isRegularFile(newer)&&digest(newer,"SHA-256").equals(previous.getProperty("sha256"))) {
                    pack=new Pack(old,oldRelease,Files.size(newer),previous.getProperty("sha256"),digest(newer,"SHA-1"),null,false);
                    log.accept("Зберігаю новіший установлений "+oldRelease+"; відкат до старої версії не потрібний.");
                }
            }
            Path stage=Files.createTempDirectory(state,"graphics-stage-");
            try {
                Path archive=stage.resolve(pack.filename());
                Path installed=game.resolve("shaderpacks").resolve(pack.filename());noLink(game,installed);
                if(Files.isRegularFile(installed)&&digest(installed,"SHA-256").equals(pack.sha256()))Files.copy(installed,archive);
                else if(pack.embedded()) {
                    log.accept("Підготовка вбудованого "+pack.release()+"…");
                    try(InputStream in=GraphicsInstaller.class.getResourceAsStream("/graphics/"+pack.filename());OutputStream out=Files.newOutputStream(archive)){
                        if(in==null||transfer(in,out,MAX_PACK)!=pack.size())throw new IOException("Вбудований пак відсутній або неповний.");
                    }
                } else {log.accept("Завантаження графіки "+pack.release()+"…");download(pack.url(),archive,pack.size());}
                if(Files.size(archive)!=pack.size()||!digest(archive,"SHA-256").equals(pack.sha256())||!digest(archive,"SHA-1").equals(pack.sha1()))throw new IOException("Контрольна сума графічного пакета не збігається.");
                Properties profiles=validatePack(archive);log.accept("Пакет перевірено: SHA-256, SHA-1 і ZIP CRC.");
                Map<Path,Path> writes=new LinkedHashMap<>();List<Path> removals=new ArrayList<>();
                if(Files.exists(installed)&&!digest(installed,"SHA-256").equals(pack.sha256()))throw new IOException("У shaderpacks уже є інший файл із назвою "+pack.filename());
                writes.put(installed,archive);
                if(textures) {
                    Path target=game.resolve("resourcepacks").resolve(pack.filename());noLink(game,target);
                    if(Files.exists(target)&&!digest(target,"SHA-256").equals(pack.sha256()))throw new IOException("У resourcepacks уже є інший файл із цією назвою.");
                    writes.put(target,archive);stageBytes(stage,writes,game.resolve("options.txt"),textureOptions(game.resolve("options.txt"),old,pack.filename()));
                }
                Path options=game.resolve("shaderpacks").resolve(pack.filename()+".txt");noLink(game,options);
                Properties values=properties(options);
                if(values.isEmpty()&&!old.isBlank()){Path oldConfig=game.resolve("shaderpacks").resolve(old+".txt");noLink(game,oldConfig);values=properties(oldConfig);}
                if(explicit||values.isEmpty()||!profile.equals(previous.getProperty("profile",profile))) {
                    for(String token:profiles.getProperty("profile."+profile).trim().split("\\s+")){
                        if(token.contains("=")){int at=token.indexOf('=');values.setProperty(token.substring(0,at),token.substring(at+1));}
                        else values.setProperty(token.startsWith("!")?token.substring(1):token,Boolean.toString(!token.startsWith("!")));
                    }
                }
                stageBytes(stage,writes,options,encode(values));
                Path iris=game.resolve("config/iris.properties");noLink(game,iris);Properties irisConfig=properties(iris);
                irisConfig.setProperty("shaderPack",pack.filename());
                if(explicit||!irisConfig.containsKey("enableShaders"))irisConfig.setProperty("enableShaders","true");
                stageBytes(stage,writes,iris,encode(irisConfig));
                if(renderer)prepareRenderers(game,stage,writes,removals,offline);
                if(!old.isBlank()&&!old.equals(pack.filename())&&previous.getProperty("sha256","").matches("[a-f0-9]{64}")) {
                    for(String directory:List.of("shaderpacks","resourcepacks")) {
                        Path owned=game.resolve(directory).resolve(old);noLink(game,owned);
                        if(Files.isRegularFile(owned)&&digest(owned,"SHA-256").equals(previous.getProperty("sha256")))removals.add(owned);
                    }
                }
                Properties record=new Properties();record.setProperty("pack",pack.filename());record.setProperty("profile",profile);record.setProperty("sha256",pack.sha256());record.setProperty("release",pack.release());
                stageBytes(stage,writes,state.resolve("graphics.properties"),encode(record));
                Path backup=commit(game,state,stage,writes,removals);
                Status status=status(game);log.accept("Встановлено "+pack.release()+" · "+(profile.equals("full")?"Повний":"Мінімальний"));
                if(!status.rendererReady())log.accept("ZIP установлено. Для відображення потрібні Iris і Sodium у цьому інстансі.");
                return new Installed(pack.release(),pack.filename(),profile,status.rendererReady(),backup);
            } finally {try(var walk=Files.walk(stage)){for(Path p:walk.sorted(Comparator.reverseOrder()).toList())Files.deleteIfExists(p);}}
        }catch(OverlappingFileLockException e){throw new IOException("Інше оновлення вже працює.",e);}
    }
    private void prepareRenderers(Path game,Path stage,Map<Path,Path> writes,List<Path> removals,boolean offline) throws Exception {
        Path mods=game.resolve("mods");noLink(game,mods);
        Map<String,Object> manifest=bundled("renderers.json");
        if(!(manifest.get("files") instanceof List<?> files)||files.size()!=2)throw new IOException("Неповний список графічних модулів.");
        for(Object entry:files) {
            Map<String,Object> m=Json.object(entry);String id=Json.text(m,"id"),name=Json.text(m,"filename"),hash=Json.text(m,"sha512");long size=Json.integer(m,"size");
            String project=id.equals("iris")?"YL57xq9U":id.equals("sodium")?"AANobbMI":"";
            URI url=URI.create(Json.text(m,"url"));
            if(project.isEmpty()||!name.matches("[A-Za-z0-9._+ -]+\\.jar")||!hash.matches("[a-f0-9]{128}")||size<1||size>64L*1024*1024
                ||!"https".equals(url.getScheme())||!"cdn.modrinth.com".equals(url.getHost())||url.getUserInfo()!=null||url.getPort()!=-1||url.getRawQuery()!=null||url.getRawFragment()!=null
                ||!url.getPath().startsWith("/data/"+project+"/versions/")||!url.getPath().endsWith("/"+name))throw new IOException("Некоректне джерело Iris/Sodium.");
            List<Path> existing=new ArrayList<>();
            if(Files.isDirectory(mods))try(var stream=Files.newDirectoryStream(mods,"*.jar")){for(Path p:stream){noLink(game,p);if(id.equals(modId(p)))existing.add(p);}}
            Path target=mods.resolve(name);noLink(game,target);
            if(Files.exists(target)&&!existing.contains(target))throw new IOException("Конфлікт стороннього файла: "+name);
            if(existing.size()==1&&digest(existing.get(0),"SHA-512").equals(hash)){log.accept(id+": сумісна версія вже встановлена.");continue;}
            if(offline)throw new IOException("Для встановлення Iris/Sodium потрібен інтернет. Пак окремо: --no-renderer.");
            log.accept("Завантаження "+id+" "+Json.text(m,"version")+"…");Path file=stage.resolve(name);download(url,file,size);
            if(!digest(file,"SHA-512").equals(hash))throw new IOException("SHA-512 не збігається: "+name);
            validateJar(file,id);writes.put(target,file);removals.addAll(existing);
        }
    }
    private static void stageBytes(Path stage,Map<Path,Path> writes,Path target,byte[] data) throws IOException {
        Path file=Files.createTempFile(stage,"config-",".tmp");Files.write(file,data);writes.put(target,file);
    }
    private Path commit(Path game,Path state,Path stage,Map<Path,Path> writes,List<Path> removals) throws Exception {
        Map<Path,Path> backups=new LinkedHashMap<>();Set<Path> changed=new LinkedHashSet<>();
        Map<Path,Path> pending=new LinkedHashMap<>();
        for(var e:writes.entrySet()){noLink(game,e.getKey());if(!Files.isRegularFile(e.getKey())||Files.mismatch(e.getKey(),e.getValue())!=-1)pending.put(e.getKey(),e.getValue());}
        removals=new ArrayList<>(new LinkedHashSet<>(removals));removals.removeIf(p->writes.containsKey(p)&&!pending.containsKey(p));
        if(pending.isEmpty()&&removals.isEmpty()){log.accept("Графіка вже актуальна. Змін не потрібно.");return null;}
        Path backup=state.resolve("backups/graphics-"+System.currentTimeMillis()+"-"+UUID.randomUUID().toString().substring(0,8));Files.createDirectories(backup);
        Set<Path> affected=new LinkedHashSet<>(pending.keySet());affected.addAll(removals);
        // Save every previous file before the first mutation.
        for(Path target:affected){noLink(game,target);if(Files.exists(target)){if(!Files.isRegularFile(target))throw new IOException("Замість файла знайдено каталог: "+target);Path saved=backup.resolve(game.relativize(target));Files.createDirectories(saved.getParent());Files.copy(target,saved);backups.put(target,saved);}}
        try {
            for(Path target:removals){Files.deleteIfExists(target);changed.add(target);}
            for(var e:pending.entrySet()){
                Path target=e.getKey();Files.createDirectories(target.getParent());noLink(game,target);
                Path tmp=Files.createTempFile(target.getParent(),"hc-install-",".tmp");
                try{Files.copy(e.getValue(),tmp,REPLACE_EXISTING);try{Files.move(tmp,target,ATOMIC_MOVE,REPLACE_EXISTING);}catch(AtomicMoveNotSupportedException unsupported){Files.move(tmp,target,REPLACE_EXISTING);}changed.add(target);}
                finally{Files.deleteIfExists(tmp);}
            }
        }catch(Exception failure){
            List<Exception> errors=new ArrayList<>();for(Path target:changed)try{if(backups.containsKey(target))Files.copy(backups.get(target),target,REPLACE_EXISTING);else Files.deleteIfExists(target);}catch(IOException e){errors.add(e);}
            if(!errors.isEmpty())throw new IOException("Відкат неповний. Резервна копія: "+backup,failure);
            throw new IOException("Встановлення скасовано; попередні файли відновлені: "+failure.getMessage(),failure);
        }
        log.accept("Резервна копія: "+backup);return backup;
    }
}
