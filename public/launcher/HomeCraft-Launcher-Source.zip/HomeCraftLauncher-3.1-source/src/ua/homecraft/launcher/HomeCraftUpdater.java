package ua.homecraft.launcher;

import java.io.*;
import java.net.*;
import java.net.http.*;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.function.Consumer;
import java.util.regex.*;
import java.util.zip.*;

import static java.nio.file.StandardCopyOption.*;

/** HomeCraft client updater. Java 17+, standard library. No mod code is executed by the updater. */
final class HomeCraftUpdater {
    static final String VERSION = "3.1.0";
    private static final Set<String> IDS = Set.of("homecraftauth", "homecraftchat", "homecraftguild", "homecraftspawnprotection", "realtime");
    private static final long MAX_JAR = 64L * 1024 * 1024;
    private static final long MAX_MANIFEST = 512L * 1024;
    private static final long MAX_ZIP_UNCOMPRESSED = 512L * 1024 * 1024;
    private static final int MAX_ZIP_ENTRIES = 20000;
    private static final Pattern FILENAME = Pattern.compile("[A-Za-z0-9][A-Za-z0-9._+ -]{0,180}\\.jar", Pattern.CASE_INSENSITIVE);
    private static final Pattern HASH = Pattern.compile("[a-fA-F0-9]{64}");
    private static final Pattern MOD_BLOCK = Pattern.compile("(?is)\\[\\[mods\\]\\](.*?)(?=\\[\\[|\\z)");
    private static final Pattern ID_LINE = Pattern.compile("(?im)^\\s*modId\\s*=\\s*['\"]([A-Za-z0-9_.-]+)['\"]");
    private static final Pattern VERSION_LINE = Pattern.compile("(?im)^\\s*version\\s*=\\s*['\"]([^'\"]+)['\"]");
    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(12))
            .followRedirects(HttpClient.Redirect.NEVER).build();
    private final Consumer<String> log;
    record Mod(String id, String name, String version, String filename, long size, String sha256, URI url) {}
    record Row(Mod remote, List<Path> installed, boolean current) {
        String status() {return current ? "Актуальний" : installed.isEmpty() ? "Не встановлено" : "Потрібне оновлення";}
    }
    record Result(List<Row> rows, int updated) {}
    static final class UpdateException extends Exception {
        UpdateException(String msg) {super(msg);}
        UpdateException(String msg, Throwable cause) {super(msg,cause);}
    }
    HomeCraftUpdater(Consumer<String> log) {this.log=log;}
    private static UpdateException error(String msg) {return new UpdateException(msg);}
    static URI baseUri(String address, boolean allowHttp) throws UpdateException {
        try {
            URI uri = URI.create(address.trim()); String scheme=uri.getScheme();
            if (scheme==null || uri.getHost()==null || uri.getUserInfo()!=null || uri.getRawQuery()!=null
                    || uri.getRawFragment()!=null || !uri.getPath().matches("/?") || uri.getHost().isBlank())
                throw error("Вкажіть лише адресу сайту (протокол, хост, порт).");
            if (!scheme.equalsIgnoreCase("https") && !scheme.equalsIgnoreCase("http"))
                throw error("Дозволено тільки HTTP та HTTPS.");
            boolean local=Set.of("localhost","127.0.0.1","::1").contains(uri.getHost().toLowerCase(Locale.ROOT));
            if (scheme.equalsIgnoreCase("http") && !local && !allowHttp)
                throw error("Для HTTP у мережі потрібно явно ввімкнути «Дозволити HTTP». Для інтернету використовуйте HTTPS.");
            return new URI(scheme.toLowerCase(Locale.ROOT),null,uri.getHost(),uri.getPort(),"/",null,null);
        } catch (IllegalArgumentException | URISyntaxException e) {throw new UpdateException("Некоректна адреса сайту",e);}
    }
    private static boolean sameOrigin(URI a, URI b) {
        return Objects.equals(a.getScheme(),b.getScheme()) && Objects.equals(a.getHost(),b.getHost()) && a.getPort()==b.getPort();
    }
    private byte[] fetch(URI url, URI origin, long limit, String accept) throws UpdateException {
        if (!sameOrigin(url,origin)) throw error("Заборонено завантаження з іншого сайту.");
        try {
            HttpRequest req = HttpRequest.newBuilder(url).timeout(Duration.ofSeconds(35))
                    .header("User-Agent","HomeCraftLauncher/"+VERSION).header("Accept",accept).GET().build();
            HttpResponse<InputStream> res = http.send(req,HttpResponse.BodyHandlers.ofInputStream());
            try(InputStream in=res.body(); ByteArrayOutputStream out=new ByteArrayOutputStream()) {
                if(res.statusCode()!=200) {
                    if(res.statusCode()==503) throw error("Сервер ще не опублікував повний набір із п’яти клієнтських JAR.");
                    throw error("Помилка сайту HTTP "+res.statusCode());
                }
                int total=0; byte[] buffer=new byte[64*1024]; int n;
                while((n=in.read(buffer))!=-1) {
                    total+=n; if(total>limit) throw error("Завантажений файл перевищує допустимий розмір.");
                    out.write(buffer,0,n);
                }
                return out.toByteArray();
            }
        } catch (IOException e) {throw new UpdateException("Помилка мережі: "+e.getMessage(),e);}
          catch (InterruptedException e) {Thread.currentThread().interrupt();throw new UpdateException("Завантаження перерване",e);}
    }
    List<Mod> manifest(String address, boolean allowHttp) throws UpdateException {
        URI origin=baseUri(address,allowHttp);
        Object obj;
        try {obj=Json.parse(new String(fetch(origin.resolve("api/launcher/manifest"),origin,MAX_MANIFEST,"application/json"),StandardCharsets.UTF_8));}
        catch (RuntimeException e) {throw new UpdateException("Некоректний JSON маніфесту",e);}
        try {
            Map<String,Object> m=Json.object(obj);
            if(Json.integer(m,"schemaVersion")!=1 || !"homecraft".equals(Json.text(m,"product"))
                    || !"26.3".equals(Json.text(m,"minecraft"))) throw error("Версія/формат маніфесту не підтримуються.");
            if(!Boolean.TRUE.equals(m.get("ok")) || !Boolean.TRUE.equals(m.get("ready")))
                throw error("На сервері відсутній повний набір HomeCraft модулів.");
            if(!(m.get("files") instanceof List<?> files) || files.size()!=IDS.size())
                throw error("Маніфест має містити рівно п’ять клієнтських модів.");
            List<Mod> results=new ArrayList<>(); Set<String> names=new HashSet<>(), ids=new HashSet<>();
            for(Object entry:files) {
                Map<String,Object> e=Json.object(entry);
                String id=Json.text(e,"id"), filename=Json.text(e,"filename"), digest=Json.text(e,"sha256");
                long size=Json.integer(e,"size");
                if(!IDS.contains(id) || !ids.add(id)) throw error("Зайвий або повторний modId.");
                if (!FILENAME.matcher(filename).matches() || filename.endsWith(" ") || filename.equals(".")
                        || filename.equals("..") || !names.add(filename.toLowerCase(Locale.ROOT))) throw error("Небезпечне або повторне ім'я JAR.");
                if (size<1 || size>MAX_JAR || !HASH.matcher(digest).matches()) throw error("Некоректний розмір чи SHA-256.");
                String url=Json.text(e,"url");
                if(url.indexOf('\\')>=0 || url.indexOf('?')>=0 || url.indexOf('#')>=0 ||
                    !url.startsWith("/client-mods/") || url.startsWith("//") || url.substring(13).contains("/"))
                    throw error("Небезпечна адреса JAR.");
                // SITE encodes '+', spaces and other filename characters with encodeURIComponent.
                // Decode only the final segment and compare it with the allowlisted filename.
                URI source=origin.resolve(url.replace(" ","%20"));
                String decoded=source.getPath();
                if(!sameOrigin(origin,source) || !decoded.equals("/client-mods/"+filename)
                        || source.getRawPath().substring(13).contains("/"))
                    throw error("URL не відповідає JAR або містить небезпечне кодування.");
                String name=e.get("name") instanceof String s ? s : id;
                String version=e.get("version") instanceof String s ? s : "—";
                results.add(new Mod(id,name.substring(0,Math.min(80,name.length())),version.substring(0,Math.min(90,version.length())),filename,size,digest.toLowerCase(Locale.ROOT),source));
            }
            if(!ids.equals(IDS)) throw error("Відсутні обов'язкові моди.");
            results.sort(Comparator.comparing(Mod::id));return List.copyOf(results);
        } catch (IllegalArgumentException e) {throw new UpdateException("Некоректний вміст маніфесту: "+e.getMessage(),e);}
    }
    static Path defaultGame() {
        String home=System.getProperty("user.home");
        if (System.getProperty("os.name","").toLowerCase(Locale.ROOT).contains("win")) {
            String appData=System.getenv("APPDATA"); return Path.of(appData!=null?appData:home+"/AppData/Roaming",".minecraft");
        }
        return Path.of(home,".minecraft");
    }
    static Path settingsPath() {
        String home=System.getProperty("user.home");
        if (System.getProperty("os.name","").toLowerCase(Locale.ROOT).contains("win")) {
            String appData=System.getenv("APPDATA");return Path.of(appData!=null?appData:home+"/AppData/Roaming","HomeCraftLauncher","settings.properties");
        }
        String config=System.getenv("XDG_CONFIG_HOME"); return Path.of(config!=null?config:home+"/.config","homecraft-launcher","settings.properties");
    }
    static Properties loadSettings() {
        Properties p=new Properties();p.setProperty("site","https://homecraft-mc.pp.ua");p.setProperty("game",defaultGame().toString());
        p.setProperty("allowHttp","false");p.setProperty("launcher","");p.setProperty("instance","");
        p.setProperty("graphicsProfile","minimum");p.setProperty("autoGraphics","true");
        p.setProperty("installRenderer","true");p.setProperty("installTextures","true");p.setProperty("animations","true");
        if(Files.isRegularFile(settingsPath())) try(var in=Files.newInputStream(settingsPath())) {p.load(in);} catch(IOException ignored){}
        return p;
    }
    static void saveSettings(Properties p) throws IOException {
        Path settings=settingsPath(); Files.createDirectories(settings.getParent());
        Path tmp=Files.createTempFile(settings.getParent(),"hc-settings-",".tmp");
        try {try(var out=Files.newOutputStream(tmp)) {p.store(out,"HomeCraft Launcher Java settings");} Files.move(tmp,settings,REPLACE_EXISTING);} finally {Files.deleteIfExists(tmp);}
    }
    static void validateGame(Path folder) throws UpdateException {
        try {
            if(!Files.isDirectory(folder) || Files.isSymbolicLink(folder)) throw error("Оберіть наявну папку профілю Minecraft.");
            Path mods=folder.resolve("mods"), state=folder.resolve(".homecraft-launcher");
            if(Files.isSymbolicLink(mods) || Files.isSymbolicLink(state)) throw error("Символічні посилання в службових каталогах не підтримуються.");
            if(!Files.isDirectory(mods) && (folder.getFileName()==null||!folder.getFileName().toString().equalsIgnoreCase(".minecraft"))
                && !Files.exists(folder.resolve("options.txt")) && !Files.exists(folder.resolve("versions"))
                && !Files.exists(folder.resolve("launcher_profiles.json")))
                throw error("Обери саме папку інсталяції Minecraft (mods/options.txt/versions).");
        } catch(SecurityException ex){throw new UpdateException("Немає доступу до папки Minecraft",ex);}
    }
    static String sha256(Path file) throws UpdateException {
        try(InputStream in=Files.newInputStream(file)) {
            MessageDigest digest=MessageDigest.getInstance("SHA-256"); byte[] bytes=new byte[256*1024];int n;
            while((n=in.read(bytes))!=-1) digest.update(bytes,0,n);
            return HexFormat.of().formatHex(digest.digest());
        } catch(IOException | NoSuchAlgorithmException e){throw new UpdateException("Помилка SHA-256",e);}
    }
    private static String metadata(Path jar) {
        try(ZipFile zip=new ZipFile(jar.toFile())) {
            ZipEntry entry=zip.getEntry("META-INF/neoforge.mods.toml");
            if(entry==null) entry=zip.getEntry("META-INF/mods.toml");
            if(entry==null || entry.getSize()<0 || entry.getSize()>262144) return null;
            try(InputStream in=zip.getInputStream(entry)) {return new String(in.readNBytes(262145),StandardCharsets.UTF_8);}
        } catch(IOException e){return null;}
    }
    private static String modField(Path jar, Pattern pattern) {
        String content=metadata(jar);if(content==null) return null;
        Matcher section=MOD_BLOCK.matcher(content);
        String body=section.find()?section.group(1):content.split("\\[\\[dependencies\\.",2)[0];
        Matcher field=pattern.matcher(body);return field.find()?field.group(1):null;
    }
    static String modId(Path jar) {String id=modField(jar,ID_LINE);return id==null?null:id.toLowerCase(Locale.ROOT);}
    static String localVersion(Path jar) {String version=modField(jar,VERSION_LINE);return version==null?"—":version;}
    static void validateJar(Path jar, String expectedId) throws UpdateException {
        try (ZipFile zip=new ZipFile(jar.toFile())) {
            if(Files.size(jar)>MAX_JAR) throw error("JAR завеликий");
            int count=0; long unpacked=0; byte[] chunk=new byte[65536];
            Enumeration<? extends ZipEntry> entries=zip.entries();
            while(entries.hasMoreElements()) {
                ZipEntry e=entries.nextElement();count++; if(count>MAX_ZIP_ENTRIES) throw error("Забагато ZIP-записів");
                if(e.isDirectory()) continue;
                if(e.getSize()>MAX_ZIP_UNCOMPRESSED || e.getSize()<0) throw error("Підозрілий JAR");
                try(InputStream stream=zip.getInputStream(e)) {
                    int n; long actual=0; CRC32 crc=new CRC32();
                    while((n=stream.read(chunk))!=-1) {
                        actual+=n; unpacked+=n; crc.update(chunk,0,n);
                        if(actual>e.getSize() || unpacked>MAX_ZIP_UNCOMPRESSED) throw error("Перепакований або пошкоджений JAR");
                    }
                    if(actual!=e.getSize() || crc.getValue()!=e.getCrc())throw error("Пошкоджений ZIP CRC: "+e.getName());
                }
            }
        } catch(IOException ex){throw new UpdateException("Пошкоджений ZIP/JAR: "+jar.getFileName(),ex);}
        if(!expectedId.equals(modId(jar))) throw error("Невірний modId у "+jar.getFileName());
    }
    List<Row> plan(Path game, List<Mod> manifest) throws UpdateException {
        validateGame(game); Path mods=game.resolve("mods");
        Map<String,List<Path>> local=new HashMap<>();for(String id:IDS)local.put(id,new ArrayList<>());
        if(Files.isDirectory(mods)) try(var items=Files.newDirectoryStream(mods)) {
            for(Path candidate:items) {
                if(Files.isSymbolicLink(candidate) || !Files.isRegularFile(candidate) || !candidate.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".jar")) continue;
                String id=modId(candidate);if(local.containsKey(id))local.get(id).add(candidate);
            }
        } catch(IOException ex) {throw new UpdateException("Не вдалося прочитати mods",ex);}
        List<Row> rows=new ArrayList<>();
        for(Mod mod:manifest) {
            List<Path> existing=List.copyOf(local.get(mod.id()));boolean current=existing.size()==1 && sha256(existing.get(0)).equals(mod.sha256());
            if(Files.isDirectory(mods)) try(var items=Files.newDirectoryStream(mods)) {
                for(Path candidate:items) {
                    if(candidate.getFileName().toString().equalsIgnoreCase(mod.filename()) &&
                            (Files.isSymbolicLink(candidate) || !existing.contains(candidate)))
                        throw error("Конфлікт із чужим або некоректним файлом: "+candidate.getFileName());
                }
            } catch(IOException ex) {throw new UpdateException("Помилка перевірки файлів mods",ex);}
            rows.add(new Row(mod,existing,current));
        }
        return List.copyOf(rows);
    }
    Result check(String site, Path game, boolean allowHttp) throws UpdateException {
        List<Row> rows=plan(game,manifest(site,allowHttp));return new Result(rows,0);
    }
    Result update(String site, Path game, boolean allowHttp) throws UpdateException {
        try { GraphicsInstaller.gameClosed(game); } catch(IOException e) {throw new UpdateException(e.getMessage(),e);}
        URI origin=baseUri(site,allowHttp);List<Row> rows=plan(game,manifest(site,allowHttp));
        List<Row> pending=rows.stream().filter(r->!r.current()).toList();
        if(pending.isEmpty()) {log.accept("Усі модулі актуальні.");return new Result(rows,0);}
        Path state=game.resolve(".homecraft-launcher"), mods=game.resolve("mods");
        try {Files.createDirectories(state);Files.createDirectories(mods);} catch(IOException e){throw new UpdateException("Не вдалося створити папки",e);}
        if(Files.isSymbolicLink(state)||Files.isSymbolicLink(mods)) throw error("Символічні посилання не дозволені.");
        Path lock=state.resolve("update.lock");
        try(FileChannel channel=FileChannel.open(lock,StandardOpenOption.CREATE,StandardOpenOption.WRITE);
            FileLock ignored=channel.tryLock()) {
            if(ignored==null) throw error("Оновлення вже виконується.");
            String id=DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss").withZone(ZoneOffset.UTC).format(Instant.now())+"-"+UUID.randomUUID().toString().substring(0,8);
            Path stage=state.resolve("staging-"+id), backup=state.resolve("backups").resolve(id);
            Map<Path,Path> moved=new LinkedHashMap<>();List<Path> installed=new ArrayList<>();
            try {
                Files.createDirectories(stage);
                // Stage and validate every JAR before touching installed files.
                for(Row row:pending) {
                    Mod mod=row.remote(); log.accept("Завантаження: "+mod.name());
                    byte[] bytes=fetch(mod.url(),origin,mod.size()+1,"application/java-archive");
                    if(bytes.length!=mod.size()) throw error("Розмір файлу не збігається: "+mod.filename());
                    Path tmp=stage.resolve(mod.filename());Files.write(tmp,bytes,StandardOpenOption.CREATE_NEW);
                    if(!sha256(tmp).equals(mod.sha256())) throw error("Неправильна SHA-256: "+mod.filename());
                    validateJar(tmp,mod.id());log.accept("Перевірено: "+mod.filename());
                }
                // Re-scan in case something else modified mods while downloading.
                for(Row row:pending) {
                    String idExpected=row.remote().id();
                    for(Path old:row.installed()) if(!Files.isRegularFile(old) || !idExpected.equals(modId(old)))
                        throw error("Файли гри змінилися під час завантаження. Перезапустіть оновлення.");
                    Path target=mods.resolve(row.remote().filename());
                    if((Files.exists(target)||Files.isSymbolicLink(target))&&!row.installed().contains(target))
                        throw error("Конфлікт файлу перед встановленням: "+target.getFileName());
                }
                Files.createDirectories(backup);
                int seq=0;
                for(Row row:pending) for(Path old:row.installed()) {
                    Path saved=backup.resolve(row.remote().id()+"-"+(seq++)+"-"+old.getFileName());
                    Files.move(old,saved);moved.put(old,saved);
                }
                for(Row row:pending) {
                    Path installedFile=mods.resolve(row.remote().filename());
                    if(Files.exists(installedFile)||Files.isSymbolicLink(installedFile)) throw error("Неочікуваний конфлікт: "+installedFile);
                    Files.move(stage.resolve(row.remote().filename()),installedFile);installed.add(installedFile);
                    log.accept("Встановлено: "+row.remote().name()+" "+row.remote().version());
                }
                log.accept("Резервна копія: "+backup);
                return new Result(plan(game, rows.stream().map(Row::remote).toList()),pending.size());
            } catch(Exception failure) {
                log.accept("Помилка: виконую відкат...");List<Exception> rollbackErrors=new ArrayList<>();
                for(Path file:installed) try{Files.deleteIfExists(file);}catch(IOException e){rollbackErrors.add(e);}
                List<Map.Entry<Path,Path>> restore=new ArrayList<>(moved.entrySet());Collections.reverse(restore);
                for(var entry:restore) try {Files.move(entry.getValue(),entry.getKey());} catch(IOException e){rollbackErrors.add(e);}
                if(!rollbackErrors.isEmpty()) throw new UpdateException("Відкат частково невдалий! Відновіть JAR з "+backup+". Помилка: "+rollbackErrors.get(0),failure);
                if(failure instanceof UpdateException e) throw e;
                throw new UpdateException("Не вдалося встановити моди: "+failure.getMessage(),failure);
            } finally {
                if(Files.isDirectory(stage)) try(var walk=Files.walk(stage)) {
                    for(Path f:walk.sorted(Comparator.reverseOrder()).toList()) try {Files.deleteIfExists(f);} catch(IOException ignored2){}
                } catch(IOException ignored2){}
            }
        } catch(java.nio.channels.OverlappingFileLockException ex) {throw new UpdateException("Оновлення вже запущене",ex);}
          catch(IOException ex) {throw new UpdateException("Помилка доступу до папки: "+ex.getMessage(),ex);}
    }
}
