package ua.homecraft.launcher;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.nio.file.*;
import java.io.IOException;
import java.util.*;
import java.util.List;
import static ua.homecraft.launcher.HomeCraftUpdater.*;

/** Java Swing GUI and command line interface for Windows and Linux. */
public final class HomeCraftLauncher {
    private HomeCraftLauncher() {}
    public static void main(String[] args) {
        if(args.length>0 && args[0].equals("--preview")) {
            try{preview(args[1],args.length>2?args[2]:"play");}catch(Exception e){e.printStackTrace();System.exit(1);}return;
        }
        if(args.length>0 && (args[0].equals("--help")||args[0].equals("help"))) {usage();return;}
        if(args.length>0 && Set.of("check","update","launch","graphics-check","graphics-install").contains(args[0])) {
            int code=cli(args);if(code!=0)System.exit(code);return;
        }
        if(GraphicsEnvironment.isHeadless()) {
            System.err.println("Графічне середовище недоступне. Команди: check, update, launch; --help.");
            System.exit(2);
        }
        SwingUtilities.invokeLater(() -> new HomeCraftLauncher.Window().setVisible(true));
    }
    private static void usage() {
        System.out.println("HomeCraft Launcher "+VERSION+" — Java 17+\n"
            +"  check | update       --site URL --game-dir PATH [--allow-http]\n"
            +"  graphics-check      --game-dir PATH\n"
            +"  graphics-install    --game-dir PATH [--profile minimum|full] [--no-renderer] [--no-textures] [--offline]\n"
            +"  launch              --launcher-exe PATH [--instance PrismID] [--game-dir PATH] [--skip-graphics]\n"
            +"Перед launch відсутні моди встановлюються, старі оновлюються. Без аргументів відкривається графічне вікно. Під час встановлення Minecraft має бути закритим.");
    }
    private static int cli(String[] args) {
        Properties props=loadSettings();boolean offline=false;
        try {
            for(int i=1;i<args.length;i++) {
                String key=args[i];
                if(key.equals("--allow-http")){props.setProperty("allowHttp","true");continue;}
                if(key.equals("--no-renderer")){props.setProperty("installRenderer","false");continue;}
                if(key.equals("--no-textures")){props.setProperty("installTextures","false");continue;}
                if(key.equals("--skip-graphics")){props.setProperty("autoGraphics","false");continue;}
                if(key.equals("--offline")){offline=true;continue;}
                String setting=switch(key) {
                    case "--site" -> "site"; case "--game-dir" -> "game";
                    case "--launcher-exe" -> "launcher"; case "--instance" -> "instance";
                    case "--profile" -> "graphicsProfile";
                    default -> throw new IllegalArgumentException("Невідомий параметр: "+key);
                };
                if(++i>=args.length)throw new IllegalArgumentException("Немає значення для "+key);
                props.setProperty(setting,args[i]);
            }
            Path game=Path.of(props.getProperty("game")).toAbsolutePath().normalize();
            boolean allow=Boolean.parseBoolean(props.getProperty("allowHttp"));
            if(args[0].equals("launch")) prepareClientModules(props, System.out::println);
            if(args[0].equals("graphics-check")) {var s=GraphicsInstaller.status(game);System.out.println("Shader pack: "+s.pack()+" | Iris: "+s.iris()+" | Sodium: "+s.sodium()+" | profile: "+s.profile()+" | enabled: "+s.enabled());return 0;}
            if(args[0].equals("graphics-install") || args[0].equals("launch")&&Boolean.parseBoolean(props.getProperty("autoGraphics","true"))) {
                new GraphicsInstaller(System.out::println).install(props.getProperty("site"),game,allow,props.getProperty("graphicsProfile","minimum"),Boolean.parseBoolean(props.getProperty("installRenderer","true")),Boolean.parseBoolean(props.getProperty("installTextures","true")),offline,args[0].equals("graphics-install"));
                if(args[0].equals("graphics-install"))return 0;
            }
            if(args[0].equals("launch")){launchExternal(props.getProperty("launcher"),props.getProperty("instance"));return 0;}
            HomeCraftUpdater updater=new HomeCraftUpdater(System.out::println);
            Result result=args[0].equals("update")?updater.update(props.getProperty("site"),game,allow):updater.check(props.getProperty("site"),game,allow);
            for(Row row:result.rows())System.out.printf("%s | %s | %s → %s%n",row.remote().name(),row.status(),row.installed().isEmpty()?"—":localVersion(row.installed().get(0)),row.remote().version());
            if(args[0].equals("update"))System.out.println("Оновлено модулів: "+result.updated());
            return 0;
        }catch(Exception e){System.err.println("Помилка: "+e.getMessage());return 1;}
    }
    static Result prepareClientModules(Properties props, java.util.function.Consumer<String> log) throws UpdateException {
        Path game=Path.of(props.getProperty("game")).toAbsolutePath().normalize();
        return new HomeCraftUpdater(log).update(props.getProperty("site"), game,
                Boolean.parseBoolean(props.getProperty("allowHttp", "false")));
    }
    static void launchExternal(String executable, String instance) throws IOException {
        String exec=executable==null?"":executable.trim().replaceAll("^\"|\"$","");
        if(exec.isBlank()) {
            List<String> candidates=System.getProperty("os.name","").toLowerCase(Locale.ROOT).contains("win")
                    ? List.of("C:\\Program Files\\PrismLauncher\\prismlauncher.exe","C:\\Program Files (x86)\\Minecraft Launcher\\MinecraftLauncher.exe")
                    : List.of("/usr/bin/prismlauncher","/usr/local/bin/prismlauncher","/usr/bin/minecraft-launcher");
            exec=candidates.stream().filter(p->Files.isRegularFile(Path.of(p))).findFirst().orElse("");
            if(exec.isBlank())throw new IOException("Укажи шлях до встановленого Minecraft/Prism Launcher.");
        }
        Path exe=Path.of(exec);
        if(!Files.isRegularFile(exe)) throw new IOException("Ігровий лаунчер не знайдено: "+exec);
        List<String> cmd=new ArrayList<>();cmd.add(exe.toString());
        if(instance!=null && !instance.isBlank()) {
            if(!exe.getFileName().toString().toLowerCase(Locale.ROOT).contains("prism"))
                throw new IOException("ID профілю дозволений тільки для Prism Launcher.");
            cmd.add("--launch");cmd.add(instance.trim());
        }
        new ProcessBuilder(cmd).start();
    }
    static final class Window extends JFrame {
        final LauncherUI view;
        Window() {
            super("HomeCraft Launcher "+VERSION);
            setupTheme();view=new LauncherUI(loadSettings(),false);setContentPane(view);
            Rectangle bounds=GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds();
            setSize(Math.min(1120,bounds.width-30),Math.min(760,bounds.height-30));setMinimumSize(new Dimension(830,590));setLocationRelativeTo(null);
            setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
            addWindowListener(new WindowAdapter(){public void windowClosing(WindowEvent e){if(!view.running){view.stop();dispose();}}public void windowIconified(WindowEvent e){view.active(false);}public void windowDeiconified(WindowEvent e){view.active(true);}});
            addWindowFocusListener(new WindowAdapter(){public void windowGainedFocus(WindowEvent e){view.active(true);}public void windowLostFocus(WindowEvent e){view.active(false);}});
        }
    }
    static void setupTheme() {
        try{UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());}catch(Exception ignored){}
        UIManager.put("Panel.background",LauncherUI.BG);UIManager.put("Label.foreground",LauncherUI.TEXT);
        UIManager.put("ScrollPane.background",LauncherUI.BG);UIManager.put("ScrollBar.background",LauncherUI.BG);
        UIManager.put("ScrollBar.thumb",LauncherUI.LINE);UIManager.put("ScrollBar.thumbDarkShadow",LauncherUI.LINE);
        UIManager.put("ScrollBar.thumbHighlight",LauncherUI.LINE);UIManager.put("ScrollBar.width",10);
        UIManager.put("ToolTip.background",LauncherUI.CARD);UIManager.put("ToolTip.foreground",LauncherUI.TEXT);
    }
    static void preview(String file,String page) throws Exception {
        SwingUtilities.invokeAndWait(()->{
            setupTheme();Properties p=new Properties();p.setProperty("site","https://homecraft-mc.pp.ua");p.setProperty("game","D:\\Games\\.minecraftx\\instances\\HomeCraft");p.setProperty("graphicsProfile","minimum");p.setProperty("animations","false");
            int width=Integer.getInteger("homecraft.preview.width",1120),height=Integer.getInteger("homecraft.preview.height",760);
            LauncherUI view=new LauncherUI(p,true);view.setSize(width,height);view.navigate(page);layout(view);layout(view);
            java.awt.image.BufferedImage image=new java.awt.image.BufferedImage(width,height,java.awt.image.BufferedImage.TYPE_INT_RGB);
            Graphics2D g=image.createGraphics();view.paint(g);g.dispose();view.stop();
            try{javax.imageio.ImageIO.write(image,"png",Path.of(file).toFile());}catch(IOException e){throw new RuntimeException(e);}
        });
    }
    static void layout(Container c){c.doLayout();for(Component child:c.getComponents())if(child instanceof Container nested)layout(nested);}
}
