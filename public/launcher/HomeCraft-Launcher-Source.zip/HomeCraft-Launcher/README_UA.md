# HomeCraft Launcher 2.0 — Java (Windows / Linux)

Лаунчер написаний **Java 21+ / Swing**, без Python, pip, Tkinter, Gradle та сторонніх бібліотек. Один `HomeCraftLauncher.jar` працює на Windows і Linux з установленою Java 21 або новішою. Для гри Minecraft 26.3 сервер HomeCraft окремо рекомендує Java 25.

## Вміст

- `HomeCraftLauncher.jar` — уже зібраний Java-застосунок (GUI + CLI)
- `start-windows.bat`, `start-linux.sh` — запуск на Windows/Linux
- `src/ua/homecraft/launcher/` — повний вихідний код Java
- `build-windows.bat`, `build-linux.sh` — перескладання JAR з JDK 21+

## Запуск

**Windows:** встанови Java 21+ (JRE) і відкрий `start-windows.bat`, або двічі натисни `HomeCraftLauncher.jar` за наявності JAR-асоціації.

**Linux Mint / Ubuntu:**

```bash
sudo apt install openjdk-21-jre
chmod +x start-linux.sh
./start-linux.sh
```

> Назва пакета Java залежить від дистрибутива. Якщо `openjdk-21-jre` недоступний, використай іншу встановлену Java 21+ (включно з Java 25).

## Налаштування

1. Адреса **твого** HomeCraft SITE, за замовчуванням `https://homecraft-mc.pp.ua`.
2. Папка конкретного **профілю** Minecraft, що містить `mods` (Prism: `instances/<instance>/.minecraft`).
3. За бажання — шлях до оригінального Minecraft Launcher або Prism Launcher та ID інстанса Prism.
4. Натисни «Перевірити», далі «Оновити моди». Під час оновлення Minecraft має бути **закритим**.

### CLI

```bash
java -jar HomeCraftLauncher.jar check --site https://homecraft-mc.pp.ua --game-dir /path/to/.minecraft
java -jar HomeCraftLauncher.jar update --site https://homecraft-mc.pp.ua --game-dir /path/to/.minecraft
java -jar HomeCraftLauncher.jar launch --launcher-exe /usr/bin/prismlauncher --instance MyInstance
```

Для HTTP в довіреній LAN додай `--allow-http`. Для публічного сервера HTTPS обов’язковий: SHA-256 без захищеного маніфесту **не гарантує автентичності** оновлення.

## Механізм оновлення

- Маніфест: `GET /api/launcher/manifest` з існуючого SITE R5.10.
- Модулі: `homecraftauth`, `homecraftguild`, `homecraftspawnprotection`; `homecraftmap` залишається серверним.
- Завантажує весь набір потрібних JAR **до** змін у папці `mods`.
- Перевіряє `size`, SHA-256, ZIP/JAR, CRC та NeoForge `modId`.
- Не чіпає сторонні моди, світи, конфігурації, логіни чи серверні файли.
- Резервні копії: `<game>/.homecraft-launcher/backups/<timestamp>-<id>/`.
- Якщо програмне встановлення завершується помилкою, відновлює старі JAR. При раптовому вимкненні живлення може знадобитися ручне відновлення з папки backups.
- Блокування паралельних оновлень: файловий lock через Java NIO.
- Запускає зовнішній офіційний/Prism Launcher, **не** замінює авторизацію Microsoft чи HomeCraft.

### Що не робить

- Не встановлює автоматично Minecraft, NeoForge, Java або сторонні моди.
- Не оновлює сам себе, не має вбудованого акаунта Microsoft.
- Не гарантує сумісність різних версій NeoForge клієнта і сервера; на практиці версії мають збігатися.

## Ручні перевірки

Відокремлені від скриптів збирання Java та від `build-all-26.3.bat`.
Перевірено на Linux/JDK 21 із локальним HTTP-макетом SITE та синтетичними JAR: початкове встановлення трьох модів, повторний запуск без змін, резервну копію при оновленні, збереження стороннього JAR, відхилення неправильного SHA-256, URL з `%2B` для назв `+mc26.3`.

**Не перевірено:** запуск GUI на реальному Windows, реальний Minecraft/NeoForge клієнт із зібраними HomeCraft-модами, пакування в Windows EXE/інсталятор.
