@echo off
setlocal
cd /d "%~dp0"
if not exist build\classes mkdir build\classes
javac --release 21 -encoding UTF-8 -d build\classes src\ua\homecraft\launcher\Json.java src\ua\homecraft\launcher\HomeCraftUpdater.java src\ua\homecraft\launcher\HomeCraftLauncher.java
if errorlevel 1 (echo Java compilation failed & exit /b 1)
jar --create --file HomeCraftLauncher.jar --main-class ua.homecraft.launcher.HomeCraftLauncher -C build\classes .
if errorlevel 1 (echo JAR packaging failed & exit /b 1)
echo Ready: HomeCraftLauncher.jar
