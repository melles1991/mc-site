#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
if ! command -v java >/dev/null 2>&1; then
  printf '%s\n' 'Потрібна Java 21 або новіша.' >&2
  exit 1
fi
exec java -jar HomeCraftLauncher.jar "$@"
