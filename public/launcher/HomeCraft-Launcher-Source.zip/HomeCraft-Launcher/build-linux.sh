#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
mkdir -p build/classes
javac --release 21 -encoding UTF-8 -d build/classes src/ua/homecraft/launcher/*.java
jar --create --file HomeCraftLauncher.jar --main-class ua.homecraft.launcher.HomeCraftLauncher -C build/classes .
printf 'Готово: %s\n' 'HomeCraftLauncher.jar'
