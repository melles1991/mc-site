@echo off
setlocal
cd /d "%~dp0"
where java >nul 2>nul
if errorlevel 1 (
  echo Потрібна Java 21 або новіша.
  pause
  exit /b 1
)
java -jar "HomeCraftLauncher.jar" %*
if errorlevel 1 pause
