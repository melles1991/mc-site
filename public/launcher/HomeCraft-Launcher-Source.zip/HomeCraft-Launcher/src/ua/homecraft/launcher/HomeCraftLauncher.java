package ua.homecraft.launcher;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.nio.file.*;
import java.io.IOException;
import java.util.*;
import java.util.List;
import java.util.concurrent.ExecutionException;
import static ua.homecraft.launcher.HomeCraftUpdater.*;

/** Java Swing GUI and command line interface for Windows and Linux. */
public final class HomeCraftLauncher {
    private static final Color BACKGROUND=new Color(17,24,34), PANEL=new Color(28,40,54), GOLD=new Color(227,181,105);
    private static final Color FOREGROUND=new Color(241,244,247), MUTED=new Color(175,190,205);
    private HomeCraftLauncher() {}
    public static void main(String[] args) {
        if(args.length>0 && (args[0].equals("--help")||args[0].equals("help"))) {usage();return;}
        if(args.length>0 && Set.of("check","update","launch").contains(args[0])) {
            int code=cli(args);if(code!=0)System.exit(code);return;
        }
        if(GraphicsEnvironment.isHeadless()) {
            System.err.println("Графічне середовище недоступне. Команди: check, update, launch; --help.");
            System.exit(2);
        }
        SwingUtilities.invokeLater(() -> new HomeCraftLauncher.Window().setVisible(true));
    }
    private static void usage() {
        System.out.println("HomeCraft Launcher "+VERSION+" — Java 21+\n"
            +"  java -jar HomeCraftLauncher.jar check  [--site URL] [--game-dir PATH] [--allow-http]\n"
            +"  java -jar HomeCraftLauncher.jar update [--site URL] [--game-dir PATH] [--allow-http]\n"
            +"  java -jar HomeCraftLauncher.jar launch [--launcher-exe PATH] [--instance PrismID]\n"
            +"Без аргументів відкривається графічне вікно.");
    }
    private static int cli(String[] args) {
        Properties props=loadSettings();
        try {
            for(int i=1;i<args.length;i++) {
                String key=args[i];
                if(key.equals("--allow-http")){props.setProperty("allowHttp","true");continue;}
                String setting=switch(key) {
                    case "--site" -> "site"; case "--game-dir" -> "game";
                    case "--launcher-exe" -> "launcher"; case "--instance" -> "instance";
                    default -> throw new IllegalArgumentException("Невідомий параметр: "+key);
                };
                if(++i>=args.length)throw new IllegalArgumentException("Немає значення для "+key);
                props.setProperty(setting,args[i]);
            }
            if(args[0].equals("launch")) {launchExternal(props.getProperty("launcher"),props.getProperty("instance"));return 0;}
            HomeCraftUpdater updater=new HomeCraftUpdater(System.out::println);
            Path game=Path.of(props.getProperty("game")).toAbsolutePath().normalize();
            boolean allow=Boolean.parseBoolean(props.getProperty("allowHttp"));
            Result result=args[0].equals("update") ? updater.update(props.getProperty("site"),game,allow)
                    : updater.check(props.getProperty("site"),game,allow);
            for(Row row:result.rows()) {
                String installed=row.installed().isEmpty()?"—":localVersion(row.installed().get(0));
                System.out.printf("%s | %s | %s → %s%n",row.remote().name(),row.status(),installed,row.remote().version());
            }
            if(args[0].equals("update"))System.out.println("Оновлено модулів: "+result.updated());
            return 0;
        } catch(Exception e) {System.err.println("Помилка: "+e.getMessage());return 1;}
    }
    static void launchExternal(String executable, String instance) throws IOException {
        String exec=executable==null?"":executable.trim().replaceAll("^\"|\"$","");
        if(exec.isBlank()) {
            List<String> candidates=System.getProperty("os.name","").toLowerCase(Locale.ROOT).contains("win")
                    ? List.of("C:\\Program Files\\PrismLauncher\\prismlauncher.exe","C:\\Program Files (x86)\\Minecraft Launcher\\MinecraftLauncher.exe")
                    : List.of("/usr/bin/prismlauncher","/usr/local/bin/prismlauncher","/usr/bin/minecraft-launcher");
            exec=candidates.stream().filter(p->Files.isRegularFile(Path.of(p))).findFirst().orElse("");
            if(exec.isBlank())throw new IOException("Укажи шлях до встановленого Minecraft/Prism Launcher.");
        }
        Path exe=Path.of(exec);
        if(!Files.isRegularFile(exe)) throw new IOException("Ігровий лаунчер не знайдено: "+exec);
        List<String> cmd=new ArrayList<>();cmd.add(exe.toString());
        if(instance!=null && !instance.isBlank()) {
            if(!exe.getFileName().toString().toLowerCase(Locale.ROOT).contains("prism"))
                throw new IOException("ID профілю дозволений тільки для Prism Launcher.");
            cmd.add("--launch");cmd.add(instance.trim());
        }
        new ProcessBuilder(cmd).start();
    }
    static final class Window extends JFrame {
        private final Properties settings=loadSettings();
        private final JTextField site=new JTextField(settings.getProperty("site"));
        private final JTextField game=new JTextField(settings.getProperty("game"));
        private final JTextField launcher=new JTextField(settings.getProperty("launcher"));
        private final JTextField instance=new JTextField(settings.getProperty("instance"));
        private final JCheckBox allowHttp=new JCheckBox("Дозволити HTTP (лише довірена мережа)",Boolean.parseBoolean(settings.getProperty("allowHttp")));
        private final DefaultTableModel model=new DefaultTableModel(new Object[]{"Модуль","Встановлено","На сайті","Стан"},0) {
            @Override public boolean isCellEditable(int r,int c) {return false;}
        };
        private final JLabel status=new JLabel("Готовий до перевірки");
        private final JTextArea log=new JTextArea();
        private final JProgressBar busyBar=new JProgressBar();
        private final JButton check=new JButton("Перевірити"), update=new JButton("Оновити моди"), launch=new JButton("Запустити Minecraft");
        private volatile boolean running;
        Window() {
            super("HomeCraft Launcher "+VERSION+" — Java");
            setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);setSize(920,690);setMinimumSize(new Dimension(720,580));
            setLocationRelativeTo(null);getContentPane().setBackground(BACKGROUND);
            try {UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());}catch(Exception ignored){}
            JPanel content=new JPanel(new BorderLayout(0,14));content.setBorder(new EmptyBorder(18,20,18,20));content.setBackground(BACKGROUND);setContentPane(content);
            JPanel head=new JPanel(new BorderLayout(0,5));head.setBackground(BACKGROUND);
            JLabel heading=new JLabel("HOMECRAFT  •  CLIENT LAUNCHER");heading.setFont(new Font("Dialog",Font.BOLD,22));heading.setForeground(GOLD);
            JLabel sub=new JLabel("Minecraft 26.3  •  Windows / Linux  •  без Python");sub.setForeground(MUTED);
            head.add(heading,BorderLayout.NORTH);head.add(sub,BorderLayout.SOUTH);content.add(head,BorderLayout.NORTH);
            JPanel center=new JPanel(new BorderLayout(0,12));center.setBackground(BACKGROUND);content.add(center,BorderLayout.CENTER);
            JPanel settingsPanel=new JPanel(new GridBagLayout());settingsPanel.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(51,72,94)),new EmptyBorder(12,13,12,13)));
            settingsPanel.setBackground(PANEL);center.add(settingsPanel,BorderLayout.NORTH);
            addField(settingsPanel,0,"Адреса сайту",site,null);
            addField(settingsPanel,1,"Папка профілю Minecraft",game,()->chooseDirectory(game));
            addField(settingsPanel,2,"Minecraft / Prism Launcher",launcher,()->chooseFile(launcher));
            addField(settingsPanel,3,"Prism ID (необов’язково)",instance,null);
            GridBagConstraints hc=new GridBagConstraints();hc.gridx=1;hc.gridy=4;hc.anchor=GridBagConstraints.WEST;hc.insets=new Insets(6,2,2,2);
            allowHttp.setBackground(PANEL);allowHttp.setForeground(MUTED);settingsPanel.add(allowHttp,hc);
            JPanel tableAndLog=new JPanel(new BorderLayout(0,10));tableAndLog.setBackground(BACKGROUND);center.add(tableAndLog,BorderLayout.CENTER);
            JTable table=new JTable(model);table.setRowHeight(30);table.setFillsViewportHeight(true);table.setBackground(PANEL);table.setForeground(FOREGROUND);
            table.setSelectionBackground(new Color(58,81,102));table.setGridColor(new Color(50,69,87));
            table.getTableHeader().setFont(new Font("Dialog",Font.BOLD,12));
            JScrollPane tableScroll=new JScrollPane(table);tableScroll.setPreferredSize(new Dimension(850,155));tableAndLog.add(tableScroll,BorderLayout.NORTH);
            log.setEditable(false);log.setFont(new Font("Monospaced",Font.PLAIN,12));log.setBackground(new Color(10,20,30));log.setForeground(FOREGROUND);
            JScrollPane logScroll=new JScrollPane(log);logScroll.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(new Color(51,72,94)),"Журнал оновлення"));
            tableAndLog.add(logScroll,BorderLayout.CENTER);
            JPanel foot=new JPanel(new BorderLayout(0,8));foot.setBackground(BACKGROUND);content.add(foot,BorderLayout.SOUTH);
            busyBar.setIndeterminate(false);busyBar.setPreferredSize(new Dimension(20,4));foot.add(busyBar,BorderLayout.NORTH);
            JPanel controls=new JPanel(new FlowLayout(FlowLayout.LEFT,9,4));controls.setBackground(BACKGROUND);
            style(check,false);style(update,true);style(launch,false);
            controls.add(check);controls.add(update);controls.add(launch);foot.add(controls,BorderLayout.CENTER);
            status.setForeground(MUTED);foot.add(status,BorderLayout.SOUTH);
            check.addActionListener(e->work(false));update.addActionListener(e->work(true));
            launch.addActionListener(e->{try{save();launchExternal(launcher.getText(),instance.getText());say("Зовнішній Minecraft Launcher запущено.");}
                catch(Exception ex){showError(ex.getMessage());}});
        }
        private void addField(JPanel p,int row,String label,JTextField field,Runnable browse) {
            GridBagConstraints c=new GridBagConstraints();c.gridy=row;c.gridx=0;c.anchor=GridBagConstraints.WEST;c.insets=new Insets(5,0,5,10);
            JLabel lbl=new JLabel(label);lbl.setForeground(FOREGROUND);p.add(lbl,c);
            c.gridx=1;c.weightx=1;c.fill=GridBagConstraints.HORIZONTAL;field.setPreferredSize(new Dimension(300,29));p.add(field,c);
            if(browse!=null){c.gridx=2;c.weightx=0;c.fill=GridBagConstraints.NONE;c.insets=new Insets(5,8,5,0);
                JButton button=new JButton("Огляд…");button.addActionListener(e->browse.run());p.add(button,c);}
        }
        private void chooseDirectory(JTextField target) {
            JFileChooser file=new JFileChooser();file.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
            if(Files.isDirectory(Path.of(target.getText())))file.setCurrentDirectory(Path.of(target.getText()).toFile());
            if(file.showOpenDialog(this)==JFileChooser.APPROVE_OPTION)target.setText(file.getSelectedFile().toString());
        }
        private void chooseFile(JTextField target) {
            JFileChooser file=new JFileChooser();file.setFileSelectionMode(JFileChooser.FILES_ONLY);
            if(file.showOpenDialog(this)==JFileChooser.APPROVE_OPTION)target.setText(file.getSelectedFile().toString());
        }
        private void style(JButton button,boolean primary) {
            button.setFont(new Font("Dialog",Font.BOLD,12));button.setFocusPainted(false);
            button.setBackground(primary?GOLD:new Color(51,72,94));button.setForeground(primary?BACKGROUND:FOREGROUND);
            button.setBorder(new EmptyBorder(9,18,9,18));
        }
        private void save() throws IOException {
            settings.setProperty("site",site.getText().trim());settings.setProperty("game",game.getText().trim());
            settings.setProperty("allowHttp",Boolean.toString(allowHttp.isSelected()));
            settings.setProperty("launcher",launcher.getText().trim());settings.setProperty("instance",instance.getText().trim());
            saveSettings(settings);
        }
        private void say(String msg){SwingUtilities.invokeLater(()->{log.append(msg+"\n");log.setCaretPosition(log.getDocument().getLength());});}
        private void showError(String message) {JOptionPane.showMessageDialog(this,message,"Помилка",JOptionPane.ERROR_MESSAGE);}
        private void work(boolean install) {
            if(running)return;
            try{save();}catch(IOException ex){showError("Не вдалося зберегти налаштування: "+ex.getMessage());return;}
            final String address=site.getText().trim(); final Path folder;
            try{folder=Path.of(game.getText().trim()).toAbsolutePath().normalize();}
            catch(Exception ex){showError("Некоректна папка Minecraft");return;}
            final boolean http=allowHttp.isSelected();
            if(install && JOptionPane.showConfirmDialog(this,"Minecraft повинен бути закритим. Оновити моди зі збереженням резервної копії?", "Встановлення",JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION)return;
            running=true;check.setEnabled(false);update.setEnabled(false);busyBar.setIndeterminate(true);
            status.setText(install?"Встановлення оновлень...":"Перевірка модів...");
            SwingWorker<Result,Void> worker=new SwingWorker<>() {
                @Override protected Result doInBackground() throws Exception {
                    HomeCraftUpdater updater=new HomeCraftUpdater(Window.this::say);
                    return install?updater.update(address,folder,http):updater.check(address,folder,http);
                }
                @Override protected void done() {
                    running=false;check.setEnabled(true);update.setEnabled(true);busyBar.setIndeterminate(false);
                    try {
                        Result result=get();model.setRowCount(0);
                        for(Row row:result.rows())model.addRow(new Object[]{row.remote().name(),row.installed().isEmpty()?"—":localVersion(row.installed().get(0)),row.remote().version(),row.status()});
                        status.setText(install?"Оновлено: "+result.updated()+" — перезапустіть Minecraft":"Перевірено модулі HomeCraft");
                    } catch(InterruptedException ex){Thread.currentThread().interrupt();status.setText("Перервано");}
                    catch(ExecutionException ex){Throwable cause=ex.getCause();String msg=cause==null?ex.getMessage():cause.getMessage();say("ПОМИЛКА: "+msg);status.setText("Оновлення не завершено");showError(msg);}
                }
            };
            worker.execute();
        }
    }
}
