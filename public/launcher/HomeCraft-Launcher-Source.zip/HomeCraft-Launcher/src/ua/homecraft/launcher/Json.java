package ua.homecraft.launcher;

import java.util.*;

/** Small, strict JSON decoder for a public manifest. No script engine or third-party dependencies. */
final class Json {
    private final String source;
    private int pos;
    private Json(String source) { this.source = source; }
    static Object parse(String source) {
        Json p = new Json(source);
        Object value = p.value(0);
        p.space();
        if (p.pos != source.length()) throw p.error("Extra JSON input");
        return value;
    }
    private IllegalArgumentException error(String message) { return new IllegalArgumentException(message + " at " + pos); }
    private void space() {
        while (pos < source.length() && " \n\r\t".indexOf(source.charAt(pos)) >= 0) pos++;
    }
    private boolean take(char c) { space(); if (pos < source.length() && source.charAt(pos)==c) {pos++;return true;} return false; }
    private void require(char c) { if (!take(c)) throw error("Expected '" + c + "'"); }
    private Object value(int depth) {
        if (depth > 32) throw error("JSON nesting too deep");
        space(); if (pos >= source.length()) throw error("Unexpected end");
        char c = source.charAt(pos);
        if (c == '{') {
            pos++; Map<String,Object> m = new LinkedHashMap<>();
            if (take('}')) return m;
            do {
                space(); if (pos >= source.length() || source.charAt(pos)!='"') throw error("Object key expected");
                String k = string(); require(':'); Object v = value(depth+1);
                if (m.putIfAbsent(k,v)!=null) throw error("Duplicate key: " + k);
                if (take('}')) return m;
                require(',');
            } while (true);
        }
        if (c == '[') {
            pos++; List<Object> a = new ArrayList<>();
            if (take(']')) return a;
            do { a.add(value(depth+1)); if (take(']')) return a; require(','); } while (true);
        }
        if (c=='"') return string();
        if (source.startsWith("true",pos)) {pos+=4; return Boolean.TRUE;}
        if (source.startsWith("false",pos)) {pos+=5;return Boolean.FALSE;}
        if (source.startsWith("null",pos)) {pos+=4;return null;}
        int start=pos;
        if (c=='-') pos++;
        int digits=0; while (pos<source.length() && Character.isDigit(source.charAt(pos))) {pos++;digits++;}
        if (digits==0) throw error("Invalid number");
        if (pos<source.length() && ".eE".indexOf(source.charAt(pos))>=0) throw error("Only integer JSON numbers supported");
        try {return Long.parseLong(source.substring(start,pos));} catch (NumberFormatException e) {throw error("Number out of range");}
    }
    private String string() {
        require('"'); StringBuilder sb=new StringBuilder();
        while (pos < source.length()) {
            char c=source.charAt(pos++);
            if(c=='"') return sb.toString();
            if(c<' ') throw error("Control character in string");
            if(c=='\\') {
                if(pos>=source.length()) throw error("Bad escape");
                c=source.charAt(pos++);
                switch(c) {
                    case '"','\\','/' -> sb.append(c);
                    case 'b' -> sb.append('\b'); case 'f' -> sb.append('\f');
                    case 'n' -> sb.append('\n'); case 'r' -> sb.append('\r'); case 't' -> sb.append('\t');
                    case 'u' -> {
                        if(pos+4>source.length()) throw error("Short unicode escape");
                        try {sb.append((char) Integer.parseInt(source.substring(pos,pos+4),16));}
                        catch(NumberFormatException ex){throw error("Bad unicode escape");}
                        pos+=4;
                    }
                    default -> throw error("Unknown escape");
                }
            } else sb.append(c);
            if (sb.length()>8192) throw error("String too long");
        }
        throw error("Unterminated string");
    }
    static Map<String,Object> object(Object o) {
        if(!(o instanceof Map<?,?> map)) throw new IllegalArgumentException("JSON object required");
        Map<String,Object> result = new HashMap<>();
        for(var e:map.entrySet()) {
            if(!(e.getKey() instanceof String s)) throw new IllegalArgumentException("Invalid key");
            result.put(s,e.getValue());
        }
        return result;
    }
    static String text(Map<String,Object> m, String key) {
        if(!(m.get(key) instanceof String s)) throw new IllegalArgumentException("Missing text: " + key);
        return s;
    }
    static long integer(Map<String,Object> m,String key) {
        if(!(m.get(key) instanceof Long n)) throw new IllegalArgumentException("Missing integer: " + key);
        return n;
    }
}
