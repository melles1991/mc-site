#!/usr/bin/env sh
set -eu
SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$SCRIPT_DIR"
if [ -n "${JAVA_HOME:-}" ] && [ -x "$JAVA_HOME/bin/java" ]; then
  JAVA_CMD="$JAVA_HOME/bin/java"
elif command -v java >/dev/null 2>&1; then
  JAVA_CMD=$(command -v java)
else
  printf '%s\n' 'Потрібна Java 17 або новіша. Встанови Java або задай JAVA_HOME.' >&2
  exit 1
fi
exec "$JAVA_CMD" -Xms32m -Xmx384m -jar "$SCRIPT_DIR/HomeCraftLauncher.jar" "$@"
