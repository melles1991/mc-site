@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
where java >nul 2>nul
if errorlevel 1 (
  echo Потрібна Java 17 або новіша.
  pause
  exit /b 1
)
java -Xms32m -Xmx384m -jar "HomeCraftLauncher.jar" %*
if errorlevel 1 pause
